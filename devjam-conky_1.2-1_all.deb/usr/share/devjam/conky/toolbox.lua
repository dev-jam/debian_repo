-- ===================================================================
-- Global Variables for CPU Power Measurement
-- ===================================================================
local last_energy = nil
local last_time = nil

-- ===================================================================
-- Global Variables & State for Resolution Watcher & Caching
-- ===================================================================
local watcher_started = false
local cached_display_info = nil
local cached_scale_factor = nil

-- ===================================================================
-- Function: CPU Power Draw (intel-rapl)
-- ===================================================================
function conky_get_cpu_power()
    local file = io.open("/sys/class/powercap/intel-rapl/intel-rapl:0/energy_uj", "r")
    if not file then return "N/A" end
    
    local energy_str = file:read("*all")
    file:close()
    
    local energy = tonumber(energy_str)
    
    -- Lees exacte systeem-uptime in seconden met microseconden-precisie
    local now = nil
    local uptime_file = io.open("/proc/uptime", "r")
    if uptime_file then
        local uptime_str = uptime_file:read("*all")
        uptime_file:close()
        now = tonumber(uptime_str:match("^(%S+)"))
    else
        now = os.time()
    end
    
    if last_energy and last_time and energy and now then
        local de = energy - last_energy
        local dt = now - last_time
        
        if dt > 0 and de >= 0 then
            local watts = (de / dt) / 1000000
            last_energy = energy
            last_time = now
            return string.format("%.2f W", watts)
        end
    end
    
    last_energy = energy
    last_time = now
    return "N/A"
end

-- ===================================================================
-- Functions: Network Percentage (1 Gbit / 125 MB/s)
-- ===================================================================
function conky_down_percent(iface)
    local speed = tonumber(conky_parse('${downspeedf ' .. (iface or '') .. '}')) or 0
    local pct = (speed / 125000) * 100
    return math.min(pct, 100)
end

function conky_up_percent(iface)
    local speed = tonumber(conky_parse('${upspeedf ' .. (iface or '') .. '}')) or 0
    local pct = (speed / 125000) * 100
    return math.min(pct, 100)
end

-- ===================================================================
-- Function: Display Info (Resolution & Refresh Rate) - Met Caching!
-- ===================================================================
function conky_get_display_info()
    -- Als de resolutie al eerder is opgehaald, gebruik direct de cache
    if cached_display_info then
        return cached_display_info
    end

    local cmd = [[kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) as $out | $out.modes[] | select(.id == $out.currentModeId) | "\(.size.width)x\(.size.height)@\( ((.refreshRate - (.refreshRate | round)) | if . < 0 then -. else . end) as $diff | if $diff < 0.01 then (.refreshRate | round) else ((.refreshRate * 100 | round) / 100) end)Hz"' 2>/dev/null | head -n1]]

    local h = io.popen(cmd)
    if not h then return "N/A" end
    
    local res = h:read("*l")
    h:close()

    if res and res ~= "" then
        cached_display_info = res
        return cached_display_info
    end

    return "N/A"
end

-- ===================================================================
-- Function: Get Scaling Factor (e.g. 100%, 125%, 150%) - Met Caching!
-- ===================================================================
function conky_get_scale_factor()
    -- Als de schaal al eerder is berekend, gebruik direct de cache
    if cached_scale_factor then
        return cached_scale_factor
    end

    -- 1. Lees X11 Xft.dpi uit via xrdb (144 DPI = 150%, 120 DPI = 125%, 96 DPI = 100%)
    local cmd_dpi = [[xrdb -query 2>/dev/null | grep -i 'Xft.dpi' | grep -o '[0-9]*']]
    local h = io.popen(cmd_dpi)
    if h then
        local dpi = h:read("*l")
        h:close()
        if dpi and tonumber(dpi) and tonumber(dpi) > 0 then
            local calculated_scale = math.floor((tonumber(dpi) / 96) * 100 + 0.5)
            cached_scale_factor = string.format("%d%%", calculated_scale)
            return cached_scale_factor
        end
    end

    -- 2. Fallback: KScreen schaalfactor
    local cmd_kscreen = [[kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | "\((.scale * 100 | round))%"' 2>/dev/null | head -n1]]
    h = io.popen(cmd_kscreen)
    if h then
        local scale = h:read("*l")
        h:close()
        if scale and scale ~= "" and scale ~= "null%" then
            cached_scale_factor = scale
            return cached_scale_factor
        end
    end

    cached_scale_factor = "100%"
    return cached_scale_factor
end

-- ===================================================================
-- Resolution & Refresh Rate Watcher Starter
-- ===================================================================
function start_resolution_watcher()
    if watcher_started then return end
    watcher_started = true
    
    os.execute("nohup ~/.config/conky/display_watcher.sh >/dev/null 2>&1 &")
end

start_resolution_watcher()
