var group__pw__loop =
[
    [ "loop.h", "src_2pipewire_2loop_8h.html", null ],
    [ "pw_loop", "structpw__loop.html", [
      [ "system", "structpw__loop.html#abab71679705176a16c9e27b3115701c3", null ],
      [ "loop", "structpw__loop.html#a4624741580712c167c17bd9242be003f", null ],
      [ "control", "structpw__loop.html#a639de0bfd74cf9e292932aaed15182c5", null ]
    ] ],
    [ "pw_loop_add_source", "group__pw__loop.html#gac2a7224b391a302d02f75c4803c7f588", null ],
    [ "pw_loop_update_source", "group__pw__loop.html#gad531597a43cad4669d627b2226011067", null ],
    [ "pw_loop_remove_source", "group__pw__loop.html#ga101116180c84c3ddcad44d06e546e117", null ],
    [ "pw_loop_invoke", "group__pw__loop.html#gafff39c7f964a4b011c4fc589c6a6ec92", null ],
    [ "pw_loop_get_fd", "group__pw__loop.html#ga5789fb95e8a0ddd1c4cf8d0143878551", null ],
    [ "pw_loop_add_hook", "group__pw__loop.html#gabb397780fe21d077fa89d46e187e0ecb", null ],
    [ "pw_loop_enter", "group__pw__loop.html#ga12545a7e053006bf3865618edb6cf275", null ],
    [ "pw_loop_iterate", "group__pw__loop.html#ga509d8e5f87cb79816ac99afd2765b0e6", null ],
    [ "pw_loop_leave", "group__pw__loop.html#ga8f6b6e07508edcd3413a05deb93b1bc0", null ],
    [ "pw_loop_add_io", "group__pw__loop.html#ga6edef1937eb5fc176a6a36485eebf8ad", null ],
    [ "pw_loop_update_io", "group__pw__loop.html#gafd0bce4fa062fe5906318bbfa9442d0f", null ],
    [ "pw_loop_add_idle", "group__pw__loop.html#ga9cd661d2b33b7032f826c58614e91cfd", null ],
    [ "pw_loop_enable_idle", "group__pw__loop.html#ga8bea041a509d072fbc54cccdb842944a", null ],
    [ "pw_loop_add_event", "group__pw__loop.html#gac62ac71350289ac2b1a312761b2bb82c", null ],
    [ "pw_loop_signal_event", "group__pw__loop.html#gaa26ce5ccf840db64b7e1de4b3f57de6e", null ],
    [ "pw_loop_add_timer", "group__pw__loop.html#ga5e937f4e92704c5b7924c07605d06318", null ],
    [ "pw_loop_update_timer", "group__pw__loop.html#ga358a963dac14b2f6b57404b3fb13bb05", null ],
    [ "pw_loop_add_signal", "group__pw__loop.html#ga714ada0b1d2d9092d4e659731ccc4cb8", null ],
    [ "pw_loop_destroy_source", "group__pw__loop.html#ga5ca87923bfa2820ee6e73fbf890bac54", null ],
    [ "pw_loop_new", "group__pw__loop.html#ga1dd2c1af93f7bcb43f983f779866c639", null ],
    [ "pw_loop_destroy", "group__pw__loop.html#gade78a07ed3f7a7cb6280485224d65709", null ]
];