var group__pw__module =
[
    [ "module.h", "module_8h.html", null ],
    [ "pw_module_info", "structpw__module__info.html", [
      [ "id", "structpw__module__info.html#a027112b51093afc0ec6370a549bcb29f", null ],
      [ "filename", "structpw__module__info.html#a1578038e841f4d0e8ac4348f263124c8", null ],
      [ "args", "structpw__module__info.html#a8991e7a078e6d92aa05e1922efc5bc53", null ],
      [ "change_mask", "structpw__module__info.html#aae79b994769838377e2b549736f12de3", null ]
    ] ],
    [ "pw_module_events", "structpw__module__events.html", [
      [ "version", "structpw__module__events.html#a3b36703a786c3fac2605fa5ebde569b5", null ],
      [ "info", "structpw__module__events.html#a43374023589fe57b63f74c367a125c68", null ]
    ] ],
    [ "pw_module_methods", "structpw__module__methods.html", [
      [ "version", "structpw__module__methods.html#ac20cd689bc54dcab9452e65c58fc5da3", null ],
      [ "add_listener", "structpw__module__methods.html#ace8dfde4c073903664ba703b575f6e01", null ]
    ] ],
    [ "pw_module", "structpw__module.html", null ],
    [ "PW_TYPE_INTERFACE_Module", "group__pw__module.html#ga408cf508aabe2366f9134f443b186bcf", null ],
    [ "PW_VERSION_MODULE", "group__pw__module.html#ga6e930a12dde7bbf70d6909c634af9d97", null ],
    [ "PW_MODULE_CHANGE_MASK_PROPS", "group__pw__module.html#ga9a9305a5898d1480d8a542f300743ed6", null ],
    [ "PW_MODULE_CHANGE_MASK_ALL", "group__pw__module.html#gaaf5d15bb2ee832cc2beb1f0c2921ef8c", null ],
    [ "PW_MODULE_EVENT_INFO", "group__pw__module.html#gab095f436fa3ebb521f692fb6bf99c79f", null ],
    [ "PW_MODULE_EVENT_NUM", "group__pw__module.html#gad6d3cbf77b94e229ef370635889b8121", null ],
    [ "PW_VERSION_MODULE_EVENTS", "group__pw__module.html#gad670c8d581f68d016f475c12cff250c8", null ],
    [ "PW_MODULE_METHOD_ADD_LISTENER", "group__pw__module.html#gae35020db0760ef496a5fbe14745fd56b", null ],
    [ "PW_MODULE_METHOD_NUM", "group__pw__module.html#ga847ff9b82e7218db4383444fbdc11b51", null ],
    [ "PW_VERSION_MODULE_METHODS", "group__pw__module.html#ga9f006acecf3988802d7bd35600b3cfba", null ],
    [ "pw_module_method", "group__pw__module.html#ga6fe9156c393377696bc3d03107bcf288", null ],
    [ "pw_module_add_listener", "group__pw__module.html#ga453e9a4a774060bb10973e607213d64a", null ],
    [ "pw_module_info_update", "group__pw__module.html#gad82e2750dff043e644044553e7e0a348", null ],
    [ "pw_module_info_merge", "group__pw__module.html#ga96578d6f92ad7c0b19ae386b85cda31d", null ],
    [ "pw_module_info_free", "group__pw__module.html#ga8c4bfe6ad4da2e2443ba7985ae7527cb", null ]
];