var group__spa__hooks =
[
    [ "hook.h", "hook_8h.html", null ],
    [ "spa_hook_list", "structspa__hook__list.html", [
      [ "list", "structspa__hook__list.html#a6f6f1ee63f0ded77544da4fa3e35a732", null ]
    ] ],
    [ "spa_hook", "structspa__hook.html", [
      [ "link", "structspa__hook.html#aa750440084804e95fb24f95de3eb5d54", null ],
      [ "cb", "structspa__hook.html#a87415e24dddc82ef6048c3572a88cfd7", null ],
      [ "removed", "structspa__hook.html#a439678f47d124fd66beec84984c9de75", null ],
      [ "priv", "structspa__hook.html#ac503424bd37fd0f8b8e6ba5bb248d8a5", null ]
    ] ],
    [ "spa_hook_list_call_simple", "group__spa__hooks.html#ga85ae35aa8df17a38bcc003e0a05e73cc", null ],
    [ "spa_hook_list_do_call", "group__spa__hooks.html#gadb7d27ebaa8d5997c5420910de1db773", null ],
    [ "spa_hook_list_call", "group__spa__hooks.html#ga2c42d01721e8e9edd16e5062a880129f", null ],
    [ "spa_hook_list_call_once", "group__spa__hooks.html#ga58d3375750cb16ee5dbcb8337af46cba", null ],
    [ "spa_hook_list_call_start", "group__spa__hooks.html#gaddde6a682396fb0125849ed615c8d0c5", null ],
    [ "spa_hook_list_call_once_start", "group__spa__hooks.html#ga0b11346eb37889ef62fe6fd20abaa741", null ],
    [ "spa_hook_list_init", "group__spa__hooks.html#ga9fb6df7a8c2a772b0cc39f81bc0eec03", null ],
    [ "spa_hook_list_is_empty", "group__spa__hooks.html#ga184c539864a808c984c21f052e2ac085", null ],
    [ "spa_hook_list_append", "group__spa__hooks.html#ga4f7f50596d9e2b4e3146ed89444ab8b2", null ],
    [ "spa_hook_list_prepend", "group__spa__hooks.html#gacbc74f9ceab3dc7c5d6d8c3eca6a41e5", null ],
    [ "spa_hook_remove", "group__spa__hooks.html#gab5d20379dc8a8a17e58631045e3f6323", null ],
    [ "spa_hook_list_clean", "group__spa__hooks.html#gacb30a0a53954eed2af8041a1882eef15", null ],
    [ "spa_hook_list_isolate", "group__spa__hooks.html#gae70f84c0eb2bae8f5d08eb694969dd40", null ],
    [ "spa_hook_list_join", "group__spa__hooks.html#ga63c54fcf4a4073e230e656f3275ebaea", null ]
];