var modules =
[
    [ "Stream", "group__pw__stream.html", "group__pw__stream" ],
    [ "Filter", "group__pw__filter.html", "group__pw__filter" ],
    [ "Test Suite", "group__pwtest.html", "group__pwtest" ],
    [ "Core API", "group__api__pw__core.html", "group__api__pw__core" ],
    [ "Implementation API", "group__api__pw__impl.html", "group__api__pw__impl" ],
    [ "Utilities", "group__api__pw__util.html", "group__api__pw__util" ],
    [ "Extensions", "group__api__pw__ext.html", "group__api__pw__ext" ],
    [ "SPA", "group__api__spa.html", "group__api__spa" ]
];