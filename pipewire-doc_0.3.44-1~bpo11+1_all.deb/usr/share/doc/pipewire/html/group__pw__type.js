var group__pw__type =
[
    [ "type.h", "src_2pipewire_2type_8h.html", null ],
    [ "PW_TYPE_INFO_BASE", "group__pw__type.html#ga0cfb51651d727a4d8717eef2f60e7921", null ],
    [ "PW_TYPE_INFO_Object", "group__pw__type.html#gac0ee38218f80b11ad0586f7c30a1fc2f", null ],
    [ "PW_TYPE_INFO_OBJECT_BASE", "group__pw__type.html#ga0cf80ee6ff44b9e1a1309cd59775f91d", null ],
    [ "PW_TYPE_INFO_Interface", "group__pw__type.html#ga442acaa60232d2b5a67a5fa33f801a42", null ],
    [ "PW_TYPE_INFO_INTERFACE_BASE", "group__pw__type.html#gabd2e0accb96cd8359530ef6dc275187f", [
      [ "PW_TYPE_FIRST", "group__pw__type.html#gga06fc87d81c62e9abb8790b6e5713c55ba3b264f61faadc9037f84e239b177ff0b", null ]
    ] ],
    [ "pw_type_info", "group__pw__type.html#ga3e7088893438300a0ba3defeb6b344a1", null ]
];