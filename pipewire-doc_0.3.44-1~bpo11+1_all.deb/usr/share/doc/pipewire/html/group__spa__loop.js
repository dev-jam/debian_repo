var group__spa__loop =
[
    [ "loop.h", "spa_2include_2spa_2support_2loop_8h.html", null ],
    [ "spa_loop", "structspa__loop.html", [
      [ "iface", "structspa__loop.html#a6cd472082b361bc90f66c41b0dccea96", null ]
    ] ],
    [ "spa_loop_control", "structspa__loop__control.html", [
      [ "iface", "structspa__loop__control.html#a392f811fbacb15de863fc0265031050f", null ]
    ] ],
    [ "spa_loop_utils", "structspa__loop__utils.html", [
      [ "iface", "structspa__loop__utils.html#afd3c579e127e4a5d22c1d407e01b2803", null ]
    ] ],
    [ "spa_source", "structspa__source.html", [
      [ "loop", "structspa__source.html#afa3497b4d040a33cacc301d261786306", null ],
      [ "func", "structspa__source.html#add060762781a845877ffe088e4bb2a8d", null ],
      [ "data", "structspa__source.html#a71de19fa483b3cff326286337642c4f7", null ],
      [ "fd", "structspa__source.html#ae6a0bb20a4c3b21ae6e622c1685711a8", null ],
      [ "mask", "structspa__source.html#ad43d6b5fd83f3e86be4f6103009370cd", null ],
      [ "rmask", "structspa__source.html#a3b403afec9c365892ab175f5613a9eff", null ]
    ] ],
    [ "spa_loop_methods", "structspa__loop__methods.html", [
      [ "version", "structspa__loop__methods.html#ae7dc5184539a2425309dee69d2867dcf", null ],
      [ "add_source", "structspa__loop__methods.html#a3cc011aae850f2eda426b98655c4a43c", null ],
      [ "update_source", "structspa__loop__methods.html#aa1c58c24c44c6161f7c5d81910cc5acc", null ],
      [ "remove_source", "structspa__loop__methods.html#a72835084d3a698702f9c875ae5aada7a", null ],
      [ "invoke", "structspa__loop__methods.html#a7852de4b031351b586ed1f5375fdc863", null ]
    ] ],
    [ "spa_loop_control_hooks", "structspa__loop__control__hooks.html", [
      [ "version", "structspa__loop__control__hooks.html#a1d60078aab0c143a082ab30e91151dd2", null ],
      [ "before", "structspa__loop__control__hooks.html#a129526ea88e29db103f01666a32c2d20", null ],
      [ "after", "structspa__loop__control__hooks.html#a94545cf994d47a1acc84437e5c357141", null ]
    ] ],
    [ "spa_loop_control_methods", "structspa__loop__control__methods.html", [
      [ "version", "structspa__loop__control__methods.html#aa66e2f92b352ef1ae10b591f11086340", null ],
      [ "get_fd", "structspa__loop__control__methods.html#a2673d98892466d81baea852c94c91a39", null ],
      [ "add_hook", "structspa__loop__control__methods.html#a4af155a89512ec591bac117a3907e8c4", null ],
      [ "enter", "structspa__loop__control__methods.html#a4a64700ab318b03abb1a5ec5a5309f8a", null ],
      [ "leave", "structspa__loop__control__methods.html#a84177384a1a726c4b35a3e1d9bc8f30f", null ],
      [ "iterate", "structspa__loop__control__methods.html#a2d30cbd197ae33a77b5ccce2216ca61a", null ]
    ] ],
    [ "spa_loop_utils_methods", "structspa__loop__utils__methods.html", [
      [ "version", "structspa__loop__utils__methods.html#aefb69d2a6ad30b352b4414401a55f3e7", null ],
      [ "add_io", "structspa__loop__utils__methods.html#ae838730dc82a9f5100539437b963480d", null ],
      [ "update_io", "structspa__loop__utils__methods.html#a166d2e9aab23ce96b9d7795c3466fc6b", null ],
      [ "add_idle", "structspa__loop__utils__methods.html#a7b3ff020ed94d62852752d55b057b08d", null ],
      [ "enable_idle", "structspa__loop__utils__methods.html#a4466703d3ee6e18abc89bafea2b0c0ed", null ],
      [ "add_event", "structspa__loop__utils__methods.html#adea85519bdd59342d7012603d39b73fe", null ],
      [ "signal_event", "structspa__loop__utils__methods.html#aa30b5933fcadb8606772d95471ec7a05", null ],
      [ "add_timer", "structspa__loop__utils__methods.html#a9a94dbdf882ed804b36f041327b0410a", null ],
      [ "update_timer", "structspa__loop__utils__methods.html#abc9a0d7bb777e2c892343b1ca5a6d37d", null ],
      [ "add_signal", "structspa__loop__utils__methods.html#a0db325151cd1a27e3f6f163c6d46c5d9", null ],
      [ "destroy_source", "structspa__loop__utils__methods.html#acb650a30486b87fcab5859afd000d913", null ]
    ] ],
    [ "SPA_TYPE_INTERFACE_Loop", "group__spa__loop.html#ga5ea06c2ace410d56b97b466704b3ded7", null ],
    [ "SPA_TYPE_INTERFACE_DataLoop", "group__spa__loop.html#ga5be1a481702843ffab8cfe42d3b6cfe1", null ],
    [ "SPA_VERSION_LOOP", "group__spa__loop.html#ga50c88c59a795523063c7f48e517fce74", null ],
    [ "SPA_TYPE_INTERFACE_LoopControl", "group__spa__loop.html#gacafe7661d00fa945b3c4f3471ef3e2c3", null ],
    [ "SPA_VERSION_LOOP_CONTROL", "group__spa__loop.html#gaf08e046c937b0d412b56b0cccbeeebea", null ],
    [ "SPA_TYPE_INTERFACE_LoopUtils", "group__spa__loop.html#ga3e3c897298f750f7847db45e0785bb43", null ],
    [ "SPA_VERSION_LOOP_UTILS", "group__spa__loop.html#gae3db9595657af4faae90e6d844291fa7", null ],
    [ "SPA_VERSION_LOOP_METHODS", "group__spa__loop.html#ga84200b300d2836d9cf38eb5a66e91746", null ],
    [ "spa_loop_method", "group__spa__loop.html#ga966277f41bb16e8f06fa0f81a41bdb49", null ],
    [ "spa_loop_add_source", "group__spa__loop.html#ga99e724c104e06300d59b4648daff894c", null ],
    [ "spa_loop_update_source", "group__spa__loop.html#ga8916c3ddccbeb9675ea37c545cb2cc2d", null ],
    [ "spa_loop_remove_source", "group__spa__loop.html#ga6ce7a8e15eac63682e937bb05ff58859", null ],
    [ "spa_loop_invoke", "group__spa__loop.html#ga48cccc69f8673b5c379d2c3cd942caf4", null ],
    [ "SPA_VERSION_LOOP_CONTROL_HOOKS", "group__spa__loop.html#gacc69b9f0b161fd5ea86a3cc79a2bfa88", null ],
    [ "spa_loop_control_hook_before", "group__spa__loop.html#ga11a4d14721eeda99243ae1b90b8e3bc3", null ],
    [ "spa_loop_control_hook_after", "group__spa__loop.html#ga9dd9301212e42d0920e8817a2de0bbc5", null ],
    [ "SPA_VERSION_LOOP_CONTROL_METHODS", "group__spa__loop.html#ga2b1b3decfe2f7f50d690dba084a6f83e", null ],
    [ "spa_loop_control_method_v", "group__spa__loop.html#ga0f531ff1357bf1f6ad225faa1f99b265", null ],
    [ "spa_loop_control_method_r", "group__spa__loop.html#ga4b23dfd9d8eadc0364b62ff9bdc25e82", null ],
    [ "spa_loop_control_get_fd", "group__spa__loop.html#gab1b169d1e380c8af23a07c8b149139df", null ],
    [ "spa_loop_control_add_hook", "group__spa__loop.html#gaffe08d7788d04fa44c44fda7ab3649bb", null ],
    [ "spa_loop_control_enter", "group__spa__loop.html#ga32dfd8283bd79d057fefb94a7e1f653c", null ],
    [ "spa_loop_control_leave", "group__spa__loop.html#ga3ab19534c467fdf6055e1db9a2144e9b", null ],
    [ "spa_loop_control_iterate", "group__spa__loop.html#ga3bae0b32100f5752b3372a505c8e04f6", null ],
    [ "SPA_VERSION_LOOP_UTILS_METHODS", "group__spa__loop.html#ga3b9f5ee85f8290ef943a23ceaf5181eb", null ],
    [ "spa_loop_utils_method_v", "group__spa__loop.html#ga48a9f2265639949de21d784ca415ecc7", null ],
    [ "spa_loop_utils_method_r", "group__spa__loop.html#gad5742d5525667f7c2287e73ec46df0e1", null ],
    [ "spa_loop_utils_method_s", "group__spa__loop.html#gaa35e9bef06156668e402d9b15afa7fa5", null ],
    [ "spa_loop_utils_add_io", "group__spa__loop.html#gaf18adfccc510004e0438614046e58013", null ],
    [ "spa_loop_utils_update_io", "group__spa__loop.html#ga99ddf176c94a66d79f30e9e4387d12e4", null ],
    [ "spa_loop_utils_add_idle", "group__spa__loop.html#gae8f06c860d57f4acd23159cc7799cbd5", null ],
    [ "spa_loop_utils_enable_idle", "group__spa__loop.html#ga221f3cb24793f6525ba85d40e1829fe5", null ],
    [ "spa_loop_utils_add_event", "group__spa__loop.html#gaf67b95b170f125ee503fec3640b727ca", null ],
    [ "spa_loop_utils_signal_event", "group__spa__loop.html#ga7ee15f09051cf99399fc9022a2d69ff8", null ],
    [ "spa_loop_utils_add_timer", "group__spa__loop.html#ga7011bd80bca03b69aabd7a0e248c8454", null ],
    [ "spa_loop_utils_update_timer", "group__spa__loop.html#ga3192e99cc1772361096a4c5d3f0fd6da", null ],
    [ "spa_loop_utils_add_signal", "group__spa__loop.html#gae18de1c27e64c87d1babd2e1ce384d11", null ],
    [ "spa_loop_utils_destroy_source", "group__spa__loop.html#gad316355ee8463e9c6bf0f515801b1a91", null ],
    [ "spa_source_func_t", "group__spa__loop.html#ga809d037b8643139b58878b4b31b28cf6", null ],
    [ "spa_invoke_func_t", "group__spa__loop.html#gab59a4a2bc60d5c26983a0e0edabc6617", null ],
    [ "spa_source_io_func_t", "group__spa__loop.html#gacb78ee7f8a1948db3767b3f9c82f7370", null ],
    [ "spa_source_idle_func_t", "group__spa__loop.html#ga710acda9d2c12a7d44236e5b1024e941", null ],
    [ "spa_source_event_func_t", "group__spa__loop.html#ga4de35545ca7478aeaf64f46434262346", null ],
    [ "spa_source_timer_func_t", "group__spa__loop.html#ga12c55826c9d89a9d385da0363ee586d9", null ],
    [ "spa_source_signal_func_t", "group__spa__loop.html#ga5484a18b8cc8060d6397589465948378", null ]
];