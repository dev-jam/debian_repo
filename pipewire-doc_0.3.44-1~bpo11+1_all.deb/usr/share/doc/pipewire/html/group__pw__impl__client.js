var group__pw__impl__client =
[
    [ "impl-client.h", "impl-client_8h.html", null ],
    [ "pw_impl_client_events", "structpw__impl__client__events.html", [
      [ "version", "structpw__impl__client__events.html#a30be6d32c40038f0ae9dfdbccdf74e1b", null ],
      [ "destroy", "structpw__impl__client__events.html#a7aee6a7b912b1a37032a3a6a156def9d", null ],
      [ "free", "structpw__impl__client__events.html#a7cc746f92f5d5b8aacf5d9cd278ea575", null ],
      [ "initialized", "structpw__impl__client__events.html#a3e42dd29cba77e524cf6328d006e2b9e", null ],
      [ "info_changed", "structpw__impl__client__events.html#a64120718bec833fc87ca30ff85e01645", null ],
      [ "resource_added", "structpw__impl__client__events.html#a59d0c58fc080957b72648c77155782a1", null ],
      [ "resource_removed", "structpw__impl__client__events.html#aafead0de7de83f2b9f4d0a84c9c9dbd3", null ],
      [ "busy_changed", "structpw__impl__client__events.html#a046e956441b5395308c8ff140292dfee", null ]
    ] ],
    [ "pw_impl_client", "structpw__impl__client.html", null ],
    [ "PW_VERSION_IMPL_CLIENT_EVENTS", "group__pw__impl__client.html#ga6fce4700c18316cb3243a195ee1ab03f", null ],
    [ "pw_context_create_client", "group__pw__impl__client.html#ga56e31d5131b26c7416a1e50afd149faf", null ],
    [ "pw_impl_client_destroy", "group__pw__impl__client.html#ga106b7787f994f1a7b6e8ebaeeb971799", null ],
    [ "pw_impl_client_register", "group__pw__impl__client.html#gaa18d68ad0b126a956e93bb45874a4b4d", null ],
    [ "pw_impl_client_get_user_data", "group__pw__impl__client.html#ga882cffc4321a3ec5d4dd45a54e1754df", null ],
    [ "pw_impl_client_get_info", "group__pw__impl__client.html#ga3788630b347fd43f0c4eca2d11ea1bf5", null ],
    [ "pw_impl_client_update_properties", "group__pw__impl__client.html#gac498bf9f5b58433c440bd4aa2da78a3e", null ],
    [ "pw_impl_client_update_permissions", "group__pw__impl__client.html#ga713afa70e2aa324aee11b82f66212765", null ],
    [ "pw_impl_client_check_permissions", "group__pw__impl__client.html#ga5422a913bc7ef52ef5088825f8195e95", null ],
    [ "pw_impl_client_get_properties", "group__pw__impl__client.html#ga9926adebd99f6204badae6f034bd1754", null ],
    [ "pw_impl_client_get_context", "group__pw__impl__client.html#ga1788365a9db9ad2c545075a88e682443", null ],
    [ "pw_impl_client_get_protocol", "group__pw__impl__client.html#ga9f11741a72528cd15208ee55e1b3a901", null ],
    [ "pw_impl_client_get_core_resource", "group__pw__impl__client.html#ga808bbb69171cd46a7a7e78baad240db2", null ],
    [ "pw_impl_client_find_resource", "group__pw__impl__client.html#gae832700ad55502a8dd1bf05e0f5ab97a", null ],
    [ "pw_impl_client_get_global", "group__pw__impl__client.html#gadaf94495ed0783e476d78a1b64188e78", null ],
    [ "pw_impl_client_add_listener", "group__pw__impl__client.html#ga1220ef9049358c0737f3184727195827", null ],
    [ "pw_impl_client_set_busy", "group__pw__impl__client.html#ga16ce05fcd538772ccdb6ac91cbc43a67", null ]
];