var group__pw__buffers =
[
    [ "buffers.h", "buffers_8h.html", null ],
    [ "pw_buffers", "structpw__buffers.html", [
      [ "mem", "structpw__buffers.html#af915317f3448e471390a13c48c0d873e", null ],
      [ "buffers", "structpw__buffers.html#adf149a809c1ea9c435ae7439391c87ed", null ],
      [ "n_buffers", "structpw__buffers.html#ad2d1496ce9316c04921470078b8046c5", null ],
      [ "flags", "structpw__buffers.html#ac6dff2ff3c481e5b092fca206e0c144f", null ]
    ] ],
    [ "PW_BUFFERS_FLAG_NONE", "group__pw__buffers.html#gad3a48705dc944299d59417cfa5b35f9d", null ],
    [ "PW_BUFFERS_FLAG_NO_MEM", "group__pw__buffers.html#ga4d3d02b0d5999f11792c89f8b5ec8591", null ],
    [ "PW_BUFFERS_FLAG_SHARED", "group__pw__buffers.html#ga8ddb8f1ed0b17399af2515ce930f5b14", null ],
    [ "PW_BUFFERS_FLAG_DYNAMIC", "group__pw__buffers.html#gacb6d3cf39ad33726f3a034ae846c4751", null ],
    [ "PW_BUFFERS_FLAG_SHARED_MEM", "group__pw__buffers.html#ga9c3b4ae5b1b248c35220d86240706a31", null ],
    [ "pw_buffers_negotiate", "group__pw__buffers.html#ga096d7e73ff412f6c49fce1a8a6d99733", null ],
    [ "pw_buffers_clear", "group__pw__buffers.html#ga7701d99e8558482b0c87d2e552b1cd10", null ]
];