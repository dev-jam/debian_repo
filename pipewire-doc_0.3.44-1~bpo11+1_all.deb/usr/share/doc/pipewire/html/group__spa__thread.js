var group__spa__thread =
[
    [ "thread.h", "spa_2include_2spa_2support_2thread_8h.html", null ],
    [ "spa_thread_utils", "structspa__thread__utils.html", [
      [ "iface", "structspa__thread__utils.html#add4d911915f7c8e76b9c646389facf70", null ]
    ] ],
    [ "spa_thread_utils_methods", "structspa__thread__utils__methods.html", [
      [ "version", "structspa__thread__utils__methods.html#a68878e9b02ee15f3590d4c871a97d74a", null ],
      [ "create", "structspa__thread__utils__methods.html#af0e80ed5c979807b0326def25690beef", null ],
      [ "join", "structspa__thread__utils__methods.html#a32030849999e51af737dad5d2761c927", null ],
      [ "get_rt_range", "structspa__thread__utils__methods.html#a93b7072cec0d4898712b33c7a6808767", null ],
      [ "acquire_rt", "structspa__thread__utils__methods.html#a6423900a0115ed260e5d4b15f24285f5", null ],
      [ "drop_rt", "structspa__thread__utils__methods.html#a67cf4dee89855ce72ad3c48184e1ca01", null ]
    ] ],
    [ "spa_thread", "structspa__thread.html", null ],
    [ "SPA_TYPE_INFO_Thread", "group__spa__thread.html#ga36d6661f31950920b85cd0c48fc68a33", null ],
    [ "SPA_TYPE_INTERFACE_ThreadUtils", "group__spa__thread.html#ga6680e7f42845ca460cdaa93abd568e02", null ],
    [ "SPA_VERSION_THREAD_UTILS", "group__spa__thread.html#ga4f716da417d838544df4e82f4670b79c", null ],
    [ "SPA_VERSION_THREAD_UTILS_METHODS", "group__spa__thread.html#ga7454dd6c4ac2967b5c53936dc6ec00b5", null ],
    [ "spa_thread_utils_create", "group__spa__thread.html#gafe6a07a645eec713f168fa2c8857fa39", null ],
    [ "spa_thread_utils_join", "group__spa__thread.html#ga8dcf8fcd02dbf3c2c49afe37e40b6a43", null ],
    [ "spa_thread_utils_get_rt_range", "group__spa__thread.html#ga13cf7d6799ad80fe7e3f69874032d529", null ],
    [ "spa_thread_utils_acquire_rt", "group__spa__thread.html#ga087f55566e08c2bb1536574b7556a66f", null ],
    [ "spa_thread_utils_drop_rt", "group__spa__thread.html#gae1224b4702957d8a48f7c17cf350f5a2", null ]
];