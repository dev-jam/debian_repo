var group__pw__work__queue =
[
    [ "work-queue.h", "work-queue_8h.html", null ],
    [ "pw_work_queue", "structpw__work__queue.html", null ],
    [ "pw_work_func_t", "group__pw__work__queue.html#ga528c2be5bb8ef21bdbe8bfa44485f8bb", null ],
    [ "pw_work_queue_new", "group__pw__work__queue.html#gac75aa3950722bd57a057cc27ba0e03a6", null ],
    [ "pw_work_queue_destroy", "group__pw__work__queue.html#gaa9e1df12736d075ba973a19f4333c2eb", null ],
    [ "pw_work_queue_add", "group__pw__work__queue.html#ga31cc6b38eda61a244c7d3fd9024a74db", null ],
    [ "pw_work_queue_cancel", "group__pw__work__queue.html#ga56673e78071d8a9eb28805331c8b2245", null ],
    [ "pw_work_queue_complete", "group__pw__work__queue.html#ga7a8bde683bc6cb8091a7d7be9df250fc", null ]
];