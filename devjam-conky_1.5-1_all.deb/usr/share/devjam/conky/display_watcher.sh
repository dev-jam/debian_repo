#!/bin/bash
# Detecteert wijzigingen in resolutie, verversingsfrequentie en schaal
# (zowel X11 als Wayland) en herstart uitsluitend het Conky-proces.

pidfile="/tmp/conky_display_watcher.pid"

if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
    exit 0
fi
echo $$ > "$pidfile"
trap 'rm -f "$pidfile"' EXIT

CONKY_CONF="$HOME/.config/conky/conky.conf"

# Vindt VEILIG alleen de PID van het echte conky-proces (voorkomt sluiten van
# terminals, editors of scripts die het woord 'conky' in hun pad/naam hebben).
find_conky_pids() {
    # Gebruik pidof om alleen echte binaries te pakken
    local pids
    pids=$(pidof conky 2>/dev/null)
    
    # Fallback als pids leeg is (bijv. specifieke AppImage executables)
    if [ -z "$pids" ]; then
        for p in /proc/[0-9]*; do
            pid="${p##*/}"
            [ "$pid" = "$$" ] && continue
            exe=$(readlink -f "$p/exe" 2>/dev/null)
            if [[ "$exe" == */conky ]]; then
                pids="$pids $pid"
            fi
        done
    fi

    echo "$pids"
}

get_running_conky_cmd() {
    for pid in $(find_conky_pids); do
        tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null
        return
    done
}

get_mode() {
    # Haal modus op (resolutie + Hz) via KScreen / jq (met fallback naar xrandr)
    local mode
    mode=$(kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) as $out | $out.modes[] | select(.id == $out.currentModeId) | "\(.size.width)x\(.size.height)_\(.refreshRate)"' 2>/dev/null | head -n1)
    
    if [ -z "$mode" ] || [ "$mode" = "null" ]; then
        mode=$(xrandr --current 2>/dev/null | awk '/\*/ {for(i=1;i<=NF;i++) if($i ~ /\*/) print $1 "_" $i}' | head -n1)
    fi

    # Haal schaal op: X11 via Xft.dpi, anders KScreen
    local dpi
    dpi=$(xrdb -query 2>/dev/null | grep -i 'Xft.dpi' | grep -o '[0-9]*')

    if [ -z "$dpi" ]; then
        dpi=$(kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | (.scale * 100 | round)' 2>/dev/null | head -n1)
        [ -z "$dpi" ] && dpi=96
    fi

    echo "${mode}_scale${dpi}"
}

LAST_MODE=$(get_mode)

while true; do
    sleep 2
    NEW_MODE=$(get_mode)

    if [ -n "$NEW_MODE" ] && [ "$NEW_MODE" != "$LAST_MODE" ]; then
        running_cmd=$(get_running_conky_cmd)

        # Stop heel specifiek ALLEEN de Conky-processen
        for pid in $(find_conky_pids); do
            kill "$pid" 2>/dev/null
        done
        sleep 1

        if [ -n "$running_cmd" ]; then
            nohup $running_cmd >/dev/null 2>&1 &
        else
            nohup conky -c "$CONKY_CONF" >/dev/null 2>&1 &
        fi

        LAST_MODE="$NEW_MODE"
    fi
done
