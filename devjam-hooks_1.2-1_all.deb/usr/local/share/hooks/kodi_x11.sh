#!/bin/sh

SDDM_DIR="/etc/sddm.conf.d"

if [[ ! -e "$SDDM_DIR" ]]; then
    mkdir -p "$SDDM_DIR"
fi

cat > ${SDDM_DIR}/autologin.conf << !
[Autologin]
User=user
Session=kodi.desktop
!

cat > /etc/sddm.conf << !
!

XORG_DIR="/etc/X11/xorg.conf.d"

if [[ ! -e "$XORG_DIR" ]]; then
    mkdir -p "$XORG_DIR"
fi

cat > ${XORG_DIR}/21-compositing.conf << !
Section "Extensions"
    Option "Composite" "Disable"
EndSection
!
