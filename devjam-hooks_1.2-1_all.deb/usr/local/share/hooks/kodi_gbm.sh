#!/bin/sh

SDDM_DIR="/etc/sddm.conf.d"

if [[ ! -e "$SDDM_DIR" ]]; then
    mkdir -p "$SDDM_DIR"
fi

cat > ${SDDM_DIR}/autologin.conf << !
[Autologin]
User=user
Session=kodi-gbm.desktop
!

cat > /etc/sddm.conf << !
!

