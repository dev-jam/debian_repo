#!/bin/sh

SDDM_DIR="/etc/sddm.conf.d"

if [[ ! -e "$SDDM_DIR" ]]; then
    mkdir -p "$SDDM_DIR"
fi

cat > ${SDDM_DIR}/autologin.conf << !
[Autologin]
Relogin=false
User=user
Session=plasmax11.desktop

[General]
HaltCommand=
Numlock=on
RebootCommand=

[Theme]
Current=breeze
CursorTheme=breeze_cursors
Font=Noto Sans,10,-1,0,50,0,0,0,0,0
!


cat > /etc/sddm.conf << !
!


XORG_DIR="/etc/X11/xorg.conf.d"

if [[ ! -e "$XORG_DIR" ]]; then
    mkdir -p "$XORG_DIR"
fi

cat > ${XORG_DIR}/21-compositing.conf << !
Section "Extensions"
    Option "Composite" "Enable"
EndSection
!
