export INTEL_COMPUTE_CLASS=1
export VAAPI_MPEG4_ENABLED=1
export mesa_glthread=true
#export INTEL_SIMD_DEBUG=fs2x8 # (uncomment for Intel Xe2 or newer)
