#!/bin/sh

SDDM_DIR="/etc/sddm.conf.d"

if [[ ! -e "$SDDM_DIR" ]]; then
    mkdir -p "$SDDM_DIR"
fi

cat > ${SDDM_DIR}/autologin.conf << !
[Autologin]
Relogin=false
User=user
Session=plasma.desktop

[General]
HaltCommand=
Numlock=on
RebootCommand=

[Theme]
Current=breeze
CursorTheme=breeze_cursors
Font=Noto Sans,10,-1,0,50,0,0,0,0,0
!


cat > /etc/sddm.conf << !
!

