from __future__ import annotations

# See #940 for why lazy_import isn't used here for backwards compatibility.
from .legacy.auth import *  # noqa
