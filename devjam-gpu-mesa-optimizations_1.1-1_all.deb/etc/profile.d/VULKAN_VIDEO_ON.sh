export ANV_DEBUG=video-decode,video-encode
