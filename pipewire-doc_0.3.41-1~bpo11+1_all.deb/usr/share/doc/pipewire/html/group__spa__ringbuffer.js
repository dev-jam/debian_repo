var group__spa__ringbuffer =
[
    [ "ringbuffer.h", "ringbuffer_8h.html", null ],
    [ "spa_ringbuffer", "structspa__ringbuffer.html", [
      [ "readindex", "structspa__ringbuffer.html#a6374bbe98fbea037a4479f11cec464c2", null ],
      [ "writeindex", "structspa__ringbuffer.html#ae7b07eebf6c9f8d3266f46cdffdfca28", null ]
    ] ],
    [ "SPA_RINGBUFFER_INIT", "group__spa__ringbuffer.html#ga636d45b00fa064ed74316528cd21cab5", null ],
    [ "spa_ringbuffer_init", "group__spa__ringbuffer.html#ga23b552aedb20b289ff75899644363a15", null ],
    [ "spa_ringbuffer_set_avail", "group__spa__ringbuffer.html#ga21c5ca3c2ac3c75f19c39e2dfef3611a", null ],
    [ "spa_ringbuffer_get_read_index", "group__spa__ringbuffer.html#gaa7b051ad6a9926f26522dda14555aa9e", null ],
    [ "spa_ringbuffer_read_data", "group__spa__ringbuffer.html#ga9e1d1b2a0c6d169ee9388a765c07b698", null ],
    [ "spa_ringbuffer_read_update", "group__spa__ringbuffer.html#ga3fc30da551d1d6b3e29d875380b3e57e", null ],
    [ "spa_ringbuffer_get_write_index", "group__spa__ringbuffer.html#gae84a3778b64a5e9dbccb8f75b50e3f99", null ],
    [ "spa_ringbuffer_write_data", "group__spa__ringbuffer.html#gadaacf8c44d93c41c4e6e34b1df310fd3", null ],
    [ "spa_ringbuffer_write_update", "group__spa__ringbuffer.html#ga855a555fdb8afc184899dffbae165f82", null ]
];