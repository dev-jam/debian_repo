var group__pw__registry =
[
    [ "core.h", "core_8h.html", null ],
    [ "pw_registry_events", "structpw__registry__events.html", [
      [ "version", "structpw__registry__events.html#a94464d7de86207e80a3dff93974b1a01", null ],
      [ "global", "structpw__registry__events.html#a9a62b37a711f65f1014cb27b92ae2689", null ],
      [ "global_remove", "structpw__registry__events.html#a3fa28cf2cd3ed8739debec5bb17ace61", null ]
    ] ],
    [ "pw_registry_methods", "structpw__registry__methods.html", [
      [ "version", "structpw__registry__methods.html#a82488a74c02c5b764b0764b0d3e42fac", null ],
      [ "add_listener", "structpw__registry__methods.html#a91a13e6dbf685af929ced294d5816089", null ],
      [ "bind", "structpw__registry__methods.html#ae8175ac475b03e3d772a7dde87a07fe6", null ],
      [ "destroy", "structpw__registry__methods.html#afe6865901f9bc87f009674959d12e60c", null ]
    ] ],
    [ "PW_REGISTRY_EVENT_GLOBAL", "group__pw__registry.html#gadf3f807d7cf834259e0ee5d1fddcce7a", null ],
    [ "PW_REGISTRY_EVENT_GLOBAL_REMOVE", "group__pw__registry.html#gad6a0258ff50f7c71f7b5d42033569428", null ],
    [ "PW_REGISTRY_EVENT_NUM", "group__pw__registry.html#gac2d679d17b73a0ccb01b6afff1810ffc", null ],
    [ "PW_VERSION_REGISTRY_EVENTS", "group__pw__registry.html#ga04010cf6cd7698a6702eab918717cf58", null ],
    [ "PW_REGISTRY_METHOD_ADD_LISTENER", "group__pw__registry.html#ga911d189930ae2198ff19f8fe66dcee15", null ],
    [ "PW_REGISTRY_METHOD_BIND", "group__pw__registry.html#ga2a38f2b9474b345dd09961560fa7aaac", null ],
    [ "PW_REGISTRY_METHOD_DESTROY", "group__pw__registry.html#gad58197f43a40ed4791f74c21471fc5c8", null ],
    [ "PW_REGISTRY_METHOD_NUM", "group__pw__registry.html#gaa7d1ac6646be6feac1f071f09422ac75", null ],
    [ "PW_VERSION_REGISTRY_METHODS", "group__pw__registry.html#gad9662f67cee6e6a37df16f6ec1924434", null ],
    [ "pw_registry_method", "group__pw__registry.html#gaf689377c151cb3ddc03d0a78e4a85693", null ],
    [ "pw_registry_add_listener", "group__pw__registry.html#gaf3f240e4c00522c1c88f97c29629cf4b", null ],
    [ "pw_registry_destroy", "group__pw__registry.html#gad656ccf876a97ff1ad698a54592bead4", null ],
    [ "pw_registry_bind", "group__pw__registry.html#ga168fe367daf40b68d569ed0f72d3d183", null ]
];