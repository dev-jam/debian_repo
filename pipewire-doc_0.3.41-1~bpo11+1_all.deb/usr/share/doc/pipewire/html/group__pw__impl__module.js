var group__pw__impl__module =
[
    [ "impl-module.h", "impl-module_8h.html", null ],
    [ "pw_impl_module_events", "structpw__impl__module__events.html", [
      [ "version", "structpw__impl__module__events.html#aea5e86ba050b1b9e92bb3c7ba3425f71", null ],
      [ "destroy", "structpw__impl__module__events.html#a4cfcceec669bbbdf6697e36cd5dbae1d", null ],
      [ "free", "structpw__impl__module__events.html#a2cb2abff60d0fa2370afcb8b5c2ae830", null ],
      [ "initialized", "structpw__impl__module__events.html#a1f0de76c49fdf742fe40c6fc0799d08c", null ],
      [ "registered", "structpw__impl__module__events.html#a75c9588d21472e8d610b813bdd9a419e", null ]
    ] ],
    [ "pw_impl_module", "structpw__impl__module.html", null ],
    [ "PW_VERSION_IMPL_MODULE_EVENTS", "group__pw__impl__module.html#gadfaa9c2651ad50387ab0fa0d715015f2", null ],
    [ "pw_impl_module_init_func_t", "group__pw__impl__module.html#ga1a6f1956ed66e6d8c0209295eb9595e9", null ],
    [ "pw_context_load_module", "group__pw__impl__module.html#ga3b7be1cbd40650725cfe09a4e6a283e3", null ],
    [ "pw_impl_module_get_context", "group__pw__impl__module.html#ga6c35f2629fb33cf69e70f3725ee1554d", null ],
    [ "pw_impl_module_get_global", "group__pw__impl__module.html#ga79c951bf001263880d52d2e82217dca7", null ],
    [ "pw_impl_module_get_properties", "group__pw__impl__module.html#ga0228a5d6fa88526e9072c4194ce9ad04", null ],
    [ "pw_impl_module_update_properties", "group__pw__impl__module.html#gae6f8d169d13bd0547a0089e3c6ee29d1", null ],
    [ "pw_impl_module_get_info", "group__pw__impl__module.html#ga8e15e393258ee42574533d3bc89b8d0d", null ],
    [ "pw_impl_module_add_listener", "group__pw__impl__module.html#gaa0dc769def4bbbdef868e3158d46f569", null ],
    [ "pw_impl_module_destroy", "group__pw__impl__module.html#gafa807477a08a78056073ccf1e30893b6", null ]
];