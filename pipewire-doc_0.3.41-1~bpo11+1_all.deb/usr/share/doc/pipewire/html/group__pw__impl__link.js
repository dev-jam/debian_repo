var group__pw__impl__link =
[
    [ "impl-link.h", "impl-link_8h.html", null ],
    [ "pw_impl_link_events", "structpw__impl__link__events.html", [
      [ "version", "structpw__impl__link__events.html#a05c9fec1c6580f673d09e33005bca5ee", null ],
      [ "destroy", "structpw__impl__link__events.html#a8e6dceaefdbbe793d1eba749370a3f25", null ],
      [ "free", "structpw__impl__link__events.html#a7cf5965ff2f975aba7ac061938e1fa9c", null ],
      [ "initialized", "structpw__impl__link__events.html#ae136867ff703e789d52dbb2ef427726d", null ],
      [ "info_changed", "structpw__impl__link__events.html#a36d3179004ca94bfe99cfc7c7608321a", null ],
      [ "state_changed", "structpw__impl__link__events.html#a05b20c99f1014e62e0d032b92382f584", null ],
      [ "port_unlinked", "structpw__impl__link__events.html#ad161d67256c9fd29f54cc53dbacb10d5", null ]
    ] ],
    [ "pw_impl_link", "structpw__impl__link.html", null ],
    [ "pw_impl_port", "structpw__impl__port.html", null ],
    [ "PW_VERSION_IMPL_LINK_EVENTS", "group__pw__impl__link.html#ga38b19e4241a7f7d2d78668ee49844498", null ],
    [ "pw_context_create_link", "group__pw__impl__link.html#ga305920b83823de396ddce1347558edd8", null ],
    [ "pw_impl_link_destroy", "group__pw__impl__link.html#ga3baed016411a9a3d0f7407c3a9144b39", null ],
    [ "pw_impl_link_add_listener", "group__pw__impl__link.html#ga34599919dcc1b77b5953b0d7ace5a33e", null ],
    [ "pw_impl_link_register", "group__pw__impl__link.html#ga065a23032eb7a487d4d310432b86d584", null ],
    [ "pw_impl_link_get_context", "group__pw__impl__link.html#ga48c91099888198337878a9f3e258d5a1", null ],
    [ "pw_impl_link_get_user_data", "group__pw__impl__link.html#ga1fa527d37b91eb569cf4f70034f8953d", null ],
    [ "pw_impl_link_get_info", "group__pw__impl__link.html#ga5653fcd369b651292d95e447b9b1d0f6", null ],
    [ "pw_impl_link_get_global", "group__pw__impl__link.html#ga5d9f95f235267d94796735c582702525", null ],
    [ "pw_impl_link_get_output", "group__pw__impl__link.html#ga74d1d9f945a77d49ae6a615f6440b8a8", null ],
    [ "pw_impl_link_get_input", "group__pw__impl__link.html#ga0c9a5ad3972a32da87f71f6655158c5c", null ],
    [ "pw_impl_link_find", "group__pw__impl__link.html#gaae471d91fcebaac5ec33544b01507d75", null ]
];