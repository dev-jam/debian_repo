#!/bin/sh

apt remove --purge devjam-gpu-x11-xlibre-modesetting-tearfree devjam-gpu-x11-xlibre-modesetting-tearfree-plasma devjam-gpu-x11-xlibre-modesetting-tearfree-plasma-egl

