#!/bin/sh

mkdir -p /etc/sddm.conf.d

cat > /etc/sddm.conf.d/autologin.conf << !
[Autologin]
User=user
Session=lxqt.desktop
!

cat > /etc/sddm.conf << !
[Autologin]
User=user
Session=lxqt.desktop
!

cat >> /etc/lightdm/lightdm.conf<< !
[Seat:*]
autologin-user=user
autologin-session=lxqt.desktop
!

mkdir -p /etc/X11/xorg.conf.d

cat > /etc/X11/xorg.conf.d/21-compositing.conf << !
Section "Extensions"
    Option "Composite" "Disable"
EndSection
!
