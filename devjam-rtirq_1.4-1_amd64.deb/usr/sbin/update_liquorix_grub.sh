#!/bin/bash
CUSTOM_FILE="/etc/grub.d/11_experiment_mode_liquorix"
ROOT_UUID=$(blkid -s UUID -o value $(findmnt -n -o SOURCE /))
LATEST_KERNEL=$(ls -1 /boot/vmlinuz-*liquorix* 2>/dev/null | sort -V | tail -n1)
if [ -z "$LATEST_KERNEL" ]; then
    echo "No Liquorix kernel found in /boot!" >&2
    exit 1
fi
KERNEL_FILE=$(basename "$LATEST_KERNEL")
INITRD_FILE="initrd.img-${KERNEL_FILE#vmlinuz-}"

cat <<EOF | sudo tee "$CUSTOM_FILE" >/dev/null
#!/bin/sh
echo 1>&2 "Adding boot menu entry for Debian Experiment Mode (RTIRQ, Isolated CPUs)"
exec tail -n +4 \$0

menuentry "Debian Experiment Mode (RTIRQ, Isolated CPUs)" {
	savedefault
	load_video
	gfxmode $linux_gfx_mode
	insmod gzio
	if [ x$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
	insmod part_gpt
	insmod ext2
	search --no-floppy --fs-uuid --set=root $ROOT_UUID
	echo	'Loading Linux ${KERNEL_FILE#vmlinuz-} ...'
    linux /boot/$KERNEL_FILE root=UUID=$ROOT_UUID ro splash libata.allow_tpm=1 threadirqs isolcpus=2,3 nohz_full=2,3 rcu_nocbs=2,3 retbleeed=stuff pcore_cpus=0-7 fbcon=font:TER64x128 experiment_mode=1
	echo	'Loading initial ramdisk ...'
    initrd /boot/$INITRD_FILE
}
EOF

chmod +x "$CUSTOM_FILE"

echo "Debian Experiment Mode GRUB entry updated with $KERNEL_FILE"
