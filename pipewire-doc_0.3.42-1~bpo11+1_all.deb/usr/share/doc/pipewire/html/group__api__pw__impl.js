var group__api__pw__impl =
[
    [ "Client Impl", "group__pw__impl__client.html", "group__pw__impl__client" ],
    [ "Core Impl", "group__pw__impl__core.html", "group__pw__impl__core" ],
    [ "Device Impl", "group__pw__impl__device.html", "group__pw__impl__device" ],
    [ "Factory Impl", "group__pw__impl__factory.html", "group__pw__impl__factory" ],
    [ "Link Impl", "group__pw__impl__link.html", "group__pw__impl__link" ],
    [ "Metadata Impl", "group__pw__impl__metadata.html", "group__pw__impl__metadata" ],
    [ "Module Impl", "group__pw__impl__module.html", "group__pw__impl__module" ],
    [ "Node Impl", "group__pw__impl__node.html", "group__pw__impl__node" ],
    [ "Port Impl", "group__pw__impl__port.html", "group__pw__impl__port" ],
    [ "Buffers", "group__pw__buffers.html", "group__pw__buffers" ],
    [ "Control", "group__pw__control.html", "group__pw__control" ],
    [ "Data Loop", "group__pw__data__loop.html", "group__pw__data__loop" ],
    [ "Global", "group__pw__global.html", "group__pw__global" ],
    [ "Protocol", "group__pw__protocol.html", "group__pw__protocol" ],
    [ "Resource", "group__pw__resource.html", "group__pw__resource" ],
    [ "Thread Loop", "group__pw__thread__loop.html", "group__pw__thread__loop" ],
    [ "Work Queue", "group__pw__work__queue.html", "group__pw__work__queue" ],
    [ "impl.h", "impl_8h.html", null ]
];