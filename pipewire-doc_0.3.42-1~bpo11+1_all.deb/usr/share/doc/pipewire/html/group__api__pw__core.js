var group__api__pw__core =
[
    [ "Initialization", "group__pw__pipewire.html", "group__pw__pipewire" ],
    [ "Main Loop", "group__pw__main__loop.html", "group__pw__main__loop" ],
    [ "Context", "group__pw__context.html", "group__pw__context" ],
    [ "Client", "group__pw__client.html", "group__pw__client" ],
    [ "Core", "group__pw__core.html", "group__pw__core" ],
    [ "Device", "group__pw__device.html", "group__pw__device" ],
    [ "Factory", "group__pw__factory.html", "group__pw__factory" ],
    [ "Link", "group__pw__link.html", "group__pw__link" ],
    [ "Loop", "group__pw__loop.html", "group__pw__loop" ],
    [ "Module", "group__pw__module.html", "group__pw__module" ],
    [ "Node", "group__pw__node.html", "group__pw__node" ],
    [ "Permission", "group__pw__permission.html", "group__pw__permission" ],
    [ "Port", "group__pw__port.html", "group__pw__port" ],
    [ "Proxy", "group__pw__proxy.html", "group__pw__proxy" ],
    [ "Registry", "group__pw__registry.html", "group__pw__registry" ],
    [ "Type info", "group__pw__type.html", "group__pw__type" ],
    [ "Key Names", "group__pw__keys.html", "group__pw__keys" ]
];