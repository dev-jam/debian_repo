var group__pw__conf =
[
    [ "conf.h", "conf_8h.html", null ],
    [ "pw_conf_load_conf", "group__pw__conf.html#ga75b61160deaaa5b8f55ec5ee8d4e9b2b", null ],
    [ "pw_conf_load_state", "group__pw__conf.html#ga4aec15c4b086542d8e8bde2127fbce2f", null ],
    [ "pw_conf_save_state", "group__pw__conf.html#ga55397ea3e06d6d0ec92337ef705c34f2", null ],
    [ "pw_context_parse_conf_section", "group__pw__conf.html#gaf3087e8f7ab10df538d6d1537bb19dfc", null ]
];