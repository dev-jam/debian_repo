var group__pw__context =
[
    [ "context.h", "context_8h.html", null ],
    [ "pw_context_events", "structpw__context__events.html", [
      [ "version", "structpw__context__events.html#ad0a1b4e42b11a408175ab4f70b1bbc7c", null ],
      [ "destroy", "structpw__context__events.html#a34b60636aee5925696ca80cbbf63755e", null ],
      [ "free", "structpw__context__events.html#a9c874d491dfbdd13eb81c7b0b7561e87", null ],
      [ "check_access", "structpw__context__events.html#af3303a7f003c10bfbb454c0bbd13360c", null ],
      [ "global_added", "structpw__context__events.html#a15e3c312ad2339ed431059d76fea5a4d", null ],
      [ "global_removed", "structpw__context__events.html#a8b2b69a9c179e37c9185929535a047f0", null ]
    ] ],
    [ "pw_export_type", "structpw__export__type.html", [
      [ "link", "structpw__export__type.html#a753c33021857c67d7bd9df56ebd13116", null ],
      [ "type", "structpw__export__type.html#a2a49749c0d81fc22b2d70845a5c04e3b", null ],
      [ "func", "structpw__export__type.html#a9cdf9b8ac9d405896d45acce48fb1c72", null ]
    ] ],
    [ "pw_context", "structpw__context.html", null ],
    [ "pw_global", "structpw__global.html", null ],
    [ "pw_impl_client", "structpw__impl__client.html", null ],
    [ "PW_VERSION_CONTEXT_EVENTS", "group__pw__context.html#ga1cb169be36ad0e32410951c8ff535743", null ],
    [ "pw_context_new", "group__pw__context.html#ga560a7075bb5665ae349c85ae876e7103", null ],
    [ "pw_context_destroy", "group__pw__context.html#ga41fdab6368603144f0911541182713a1", null ],
    [ "pw_context_get_user_data", "group__pw__context.html#gaa09ebbaed5dbf26b9a304d49beecdf94", null ],
    [ "pw_context_add_listener", "group__pw__context.html#ga44d2d1b5d618438873016c764584f1e5", null ],
    [ "pw_context_get_properties", "group__pw__context.html#gaa2be0c032178ed27936b716ffa8ea4c5", null ],
    [ "pw_context_update_properties", "group__pw__context.html#ga48011f6ba07333a33f880778da4a1c86", null ],
    [ "pw_context_get_conf_section", "group__pw__context.html#ga5da58001a9cefc969bd4f55f69ae32b3", null ],
    [ "pw_context_get_support", "group__pw__context.html#ga4adfd99a7941665d15f4ad368cf68ab1", null ],
    [ "pw_context_get_main_loop", "group__pw__context.html#gae9b6023dfaa0defcf16a2ebafa901840", null ],
    [ "pw_context_get_work_queue", "group__pw__context.html#gafef9fcc0ef91738137aaa32783fdfe94", null ],
    [ "pw_context_for_each_global", "group__pw__context.html#gaaa07217fcfeba4dd0a0269ff313a75d7", null ],
    [ "pw_context_find_global", "group__pw__context.html#ga4b42764d2a50b3c1b3273246b84d1c75", null ],
    [ "pw_context_add_spa_lib", "group__pw__context.html#gace5ee0a357a22a1dd86e3398956a621e", null ],
    [ "pw_context_find_spa_lib", "group__pw__context.html#gab8cedcc93cbde35f3cb9225b969cef43", null ],
    [ "pw_context_load_spa_handle", "group__pw__context.html#ga9fa7b0905bf18003532e4740050caf09", null ],
    [ "pw_context_register_export_type", "group__pw__context.html#ga39a9e29ddc0cad4ced7d6034a64e3aff", null ],
    [ "pw_context_find_export_type", "group__pw__context.html#ga8864661d392f052418a0c8fc00929cbb", null ],
    [ "pw_context_set_object", "group__pw__context.html#ga1e67973ea8236ff8bc6125a437b79a76", null ],
    [ "pw_context_get_object", "group__pw__context.html#ga24cd5c5f4aeabae5850b5b1a85cfbcb9", null ]
];