var group__spa__i18n =
[
    [ "i18n.h", "spa_2include_2spa_2support_2i18n_8h.html", null ],
    [ "spa_i18n", "structspa__i18n.html", [
      [ "iface", "structspa__i18n.html#a4ca10c865fe33ffff4fd9abb9265c0f8", null ]
    ] ],
    [ "spa_i18n_methods", "structspa__i18n__methods.html", [
      [ "version", "structspa__i18n__methods.html#a3aa971d572e886ab027a897a288f767b", null ],
      [ "text", "structspa__i18n__methods.html#aa6a71edc71368a5cd323536ae38e836e", null ],
      [ "ntext", "structspa__i18n__methods.html#a86a65ea95402cc177242ca24f3ea9080", null ]
    ] ],
    [ "SPA_TYPE_INTERFACE_I18N", "group__spa__i18n.html#gacc03db6ab5181108527ca45e7674b235", null ],
    [ "SPA_VERSION_I18N", "group__spa__i18n.html#gab6c7211ad9795cf4c1c55487c165a555", null ],
    [ "SPA_VERSION_I18N_METHODS", "group__spa__i18n.html#gaf3aa0f8921abf9d572c9fde4a9d0825d", null ],
    [ "spa_i18n_text", "group__spa__i18n.html#ga10d9d73c6f0c36dbdc745504c0f7fb1f", null ],
    [ "spa_i18n_ntext", "group__spa__i18n.html#gaea748786409f09b708c737525240e482", null ]
];