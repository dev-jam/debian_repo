var group__spa__list =
[
    [ "list.h", "list_8h.html", null ],
    [ "spa_list", "structspa__list.html", [
      [ "next", "structspa__list.html#aed4aa24d6a3d4f62a4198296312a6196", null ],
      [ "prev", "structspa__list.html#ab67df98c96319f199a02cb48ee7de93e", null ]
    ] ],
    [ "SPA_LIST_INIT", "group__spa__list.html#gacc823f4d4d5c7fa8ee8ef00a56c0a8ec", null ],
    [ "spa_list_is_empty", "group__spa__list.html#gabb88430b81aa5bb148fb4054da84c37e", null ],
    [ "spa_list_first", "group__spa__list.html#ga94381f31e216abb3a54a9c8866318818", null ],
    [ "spa_list_last", "group__spa__list.html#gaf76607bd5d48aa7b41d693260a19b68e", null ],
    [ "spa_list_append", "group__spa__list.html#gadc766e382f0a0594ad4615fbc5fc7751", null ],
    [ "spa_list_prepend", "group__spa__list.html#gab7f00cc70bccbe6b99fba699905757dc", null ],
    [ "spa_list_is_end", "group__spa__list.html#ga1cc2697f03626118318c1506bed70767", null ],
    [ "spa_list_next", "group__spa__list.html#ga108cc4dbe3573f71ac8fa0e6d54b8dac", null ],
    [ "spa_list_prev", "group__spa__list.html#ga587a1750ebac2e8f980228db27b44e0f", null ],
    [ "spa_list_consume", "group__spa__list.html#ga60b0fbabb70671c71d40e5443f6489d8", null ],
    [ "spa_list_for_each_next", "group__spa__list.html#ga45afc4b42dfaa194a4675532338fc621", null ],
    [ "spa_list_for_each_prev", "group__spa__list.html#ga49f1884c56d222f6e7d68e437728366a", null ],
    [ "spa_list_for_each", "group__spa__list.html#gac75faa4587e0df7c11f10b3d44590a7d", null ],
    [ "spa_list_for_each_reverse", "group__spa__list.html#ga2b8d65766f4dfe2a009073a3ed3a8edb", null ],
    [ "spa_list_for_each_safe_next", "group__spa__list.html#gab5c2aa1c10907d6fe58ff398764344f6", null ],
    [ "spa_list_for_each_safe_prev", "group__spa__list.html#ga964734871c9792e189ce23a08b74c4d0", null ],
    [ "spa_list_for_each_safe", "group__spa__list.html#gadea44c074f21f2a8c15825e526110bf0", null ],
    [ "spa_list_for_each_safe_reverse", "group__spa__list.html#gae1826e761b00fde76907589f66cf74a9", null ],
    [ "spa_list_cursor_start", "group__spa__list.html#gaadec436f232586998917c75efeac05ab", null ],
    [ "spa_list_for_each_cursor", "group__spa__list.html#ga75add8c86fa73d438fdfc3568062bb45", null ],
    [ "spa_list_cursor_end", "group__spa__list.html#ga26b91db2741857b5402dbc6ec0cd7857", null ],
    [ "spa_list_init", "group__spa__list.html#ga731aaed174d63ae6cc01cddde266ed73", null ],
    [ "spa_list_insert", "group__spa__list.html#ga15db195a9509817eb07df421de1b1ffc", null ],
    [ "spa_list_insert_list", "group__spa__list.html#gafbca4263c0f4f6afba58f226bfb99198", null ],
    [ "spa_list_remove", "group__spa__list.html#ga7c4f3862b62ea26df079936f5ebfdacc", null ]
];