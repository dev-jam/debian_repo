var group__pw__permission =
[
    [ "permission.h", "permission_8h.html", null ],
    [ "pw_permission", "structpw__permission.html", [
      [ "id", "structpw__permission.html#a317a76bba04bd0dcad6e5bca65f9fa92", null ],
      [ "permissions", "structpw__permission.html#ac890cf00fa67d8667c9be52276e8a6f3", null ]
    ] ],
    [ "PW_PERM_R", "group__pw__permission.html#ga2a31ac243ad99915377319b663daf426", null ],
    [ "PW_PERM_W", "group__pw__permission.html#ga97d33a5e044ee126fd9991b8c70424aa", null ],
    [ "PW_PERM_X", "group__pw__permission.html#ga277828556118843e682c652bb1dc9c8e", null ],
    [ "PW_PERM_M", "group__pw__permission.html#ga4564637816ca41369b383af05951a3b7", null ],
    [ "PW_PERM_RWX", "group__pw__permission.html#ga77df16320c3bb338666f55b2b21e6e47", null ],
    [ "PW_PERM_RWXM", "group__pw__permission.html#ga9f4fda4d9b16f0595986e2d63265fb63", null ],
    [ "PW_PERM_CHECK", "group__pw__permission.html#ga05f4dadbac08c66280324bc9f18d5ef1", null ],
    [ "PW_PERM_IS_R", "group__pw__permission.html#ga2668b1c9a4b1e4b68fefe81e55d1ee59", null ],
    [ "PW_PERM_IS_W", "group__pw__permission.html#gaa61804de7cf6003defd8b26ef488ce56", null ],
    [ "PW_PERM_IS_X", "group__pw__permission.html#ga5dca3f2e9a9b71cc78525893eb80355b", null ],
    [ "PW_PERM_IS_M", "group__pw__permission.html#gadea4630c0fbf61f2c42de3339c81abe2", null ],
    [ "PW_PERM_ALL", "group__pw__permission.html#gab3c2f31e9ed5b2578d2d86b32a3b7103", null ],
    [ "PW_PERM_INVALID", "group__pw__permission.html#ga50224a8e3d16e9baa4be58183fec502f", null ],
    [ "PW_PERMISSION_INIT", "group__pw__permission.html#gaa6b729cf828ec6417f5ba997560fda2b", null ],
    [ "PW_PERMISSION_FORMAT", "group__pw__permission.html#ga04ee9df87cc0a2d35ddf5a54a1c2059c", null ],
    [ "PW_PERMISSION_ARGS", "group__pw__permission.html#gaff0a46d4bd012b8d421e848637d64f30", null ]
];