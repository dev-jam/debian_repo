-- ===================================================================
-- Global Variables for CPU Power Measurement
-- ===================================================================
local last_energy = nil
local last_time = nil

-- ===================================================================
-- Global Variables & State for Resolution Watcher & Caching
-- ===================================================================
local watcher_started = false
local cached_display_info = nil
local cached_scale_factor = nil

-- ===================================================================
-- Function: Display Scale Factor (5-second interval for KDE settings)
-- ===================================================================
local cached_scale = nil
local scale_last_check = 0

function get_scale(size_factor)
    size_factor = size_factor or 0.8
    local now = os.time()

    -- Only check screen scale if at least 5 seconds have passed
    if not cached_scale or (now - scale_last_check >= 5) then
        local base_scale = 1.0

        -- 1. Check Xft.dpi via xrdb first
        local handle = io.popen("xrdb -query 2>/dev/null | grep -i 'Xft.dpi'")
        if handle then
            local output = handle:read("*a")
            handle:close()
            if output then
                local dpi_str = output:match("(%d+)%s*$")
                local dpi = tonumber(dpi_str)
                if dpi and dpi > 0 then
                    base_scale = dpi / 96.0
                end
            end
        end

        -- 2. Fallback: KScreen via jq
        if base_scale == 1.0 then
            local kwin_handle = io.popen("kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | .scale' 2>/dev/null | head -n1")
            if kwin_handle then
                local kwin_scale_str = kwin_handle:read("*a")
                kwin_handle:close()
                local kwin_scale = tonumber(kwin_scale_str)
                if kwin_scale and kwin_scale > 0 then
                    base_scale = kwin_scale
                end
            end
        end

        cached_scale = base_scale
        scale_last_check = now
    end

    return cached_scale * size_factor
end

-- ===================================================================
-- Function: Get CPU Model / Brand Name
-- ===================================================================
function conky_get_cpu_name()
    local f = io.open("/proc/cpuinfo", "r")
    if not f then return "N/A" end

    local model_name = nil
    for line in f:lines() do
        model_name = line:match("^model name%s*:%s*(.+)")
        if model_name then break end
    end
    f:close()

    if model_name then
        -- Clean up model name for a clean Conky layout (strips redundant branding)
        model_name = model_name:gsub("%(R%)", "")
                              :gsub("%(TM%)", "")
                              :gsub("12th Gen ", "")
                              :gsub("13th Gen ", "")
                              :gsub("14th Gen ", "")
                              :gsub("Processor", "")
                              :gsub("CPU", "")
                              :gsub("%s+", " ")
                              :match("^%s*(.-)%s*$")
        return model_name
    end

    return "N/A"
end

-- ===================================================================
-- Function: CPU Scaling Driver (e.g. intel_pstate, amd-pstate)
-- ===================================================================
function conky_get_cpu_driver()
    local f = io.open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_driver", "r")
    if not f then return "N/A" end
    
    local driver = f:read("*l")
    f:close()
    
    if driver and driver ~= "" then
        return driver
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: Universal CPU Temperature (sensors + jq)
-- ===================================================================
function conky_get_cpu_temp()
    local cmd = [[sensors -j 2>/dev/null | jq -r 'to_entries[] | select(.key | test("^(coretemp|k10temp|zenpower|cpu_thermal)")) | .value | to_entries[] | select(.key | test("^(CPU Package|Package|Tctl|Tdie)")) | .. | .temp1_input? // .temp2_input? // empty' 2>/dev/null | head -n1]]
    
    local handle = io.popen(cmd)
    if not handle then return "N/A" end
    
    local temp_str = handle:read("*l")
    handle:close()
    
    local temp = tonumber(temp_str)
    if temp then
        return string.format("%d°C", math.floor(temp + 0.5))
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: CPU Max Frequency Across All Cores
-- ===================================================================
function conky_get_cpu_freq_max()
    local max_khz = 0
    local core = 0

    -- Iterate through all cores in /sys/devices/system/cpu/cpuX/cpufreq/scaling_cur_freq
    while true do
        local f = io.open(string.format("/sys/devices/system/cpu/cpu%d/cpufreq/scaling_cur_freq", core), "r")
        if not f then break end -- Stop when no further core is found

        local val = tonumber(f:read("*l"))
        f:close()

        if val and val > max_khz then
            max_khz = val
        end
        core = core + 1
    end

    if max_khz > 0 then
        return string.format("%.2f GHz", max_khz / 1000000)
    end

    return "N/A"
end

-- ===================================================================
-- Function: CPU Scaling Governor
-- ===================================================================
function conky_get_cpu_governor()
    local f = io.open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor", "r")
    if not f then return "N/A" end
    
    local gov = f:read("*l")
    f:close()
    
    if gov and gov ~= "" then
        return gov
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: CPU Energy Performance Preference (EPP)
-- ===================================================================
function conky_get_cpu_epp()
    local f = io.open("/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference", "r")
    if not f then return "N/A" end
    
    local epp = f:read("*l")
    f:close()
    
    if epp and epp ~= "" then
        return epp
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: CPU Power Draw (intel-rapl)
-- ===================================================================
function conky_get_cpu_power()
    local file = io.open("/sys/class/powercap/intel-rapl/intel-rapl:0/energy_uj", "r")
    if not file then return "N/A" end
    
    local energy_str = file:read("*all")
    file:close()
    
    local energy = tonumber(energy_str)
    
    -- Read exact system uptime in seconds with microsecond precision
    local now = nil
    local uptime_file = io.open("/proc/uptime", "r")
    if uptime_file then
        local uptime_str = uptime_file:read("*all")
        uptime_file:close()
        now = tonumber(uptime_str:match("^(%S+)"))
    else
        now = os.time()
    end
    
    if last_energy and last_time and energy and now then
        local de = energy - last_energy
        local dt = now - last_time
        
        if dt > 0 and de >= 0 then
            local watts = (de / dt) / 1000000
            last_energy = energy
            last_time = now
            return string.format("%.2f W", watts)
        end
    end
    
    last_energy = energy
    last_time = now
    return "N/A"
end

-- ===================================================================
-- Helper: Auto-detect Active Network Interface (Cached)
-- ===================================================================
local cached_net_iface = nil

local function get_active_interface()
    if cached_net_iface then return cached_net_iface end

    -- Parse /proc/net/dev for the first non-loopback network interface
    local f = io.open("/proc/net/dev", "r")
    if f then
        for line in f:lines() do
            local iface = line:match("^%s*([%w%-]+):")
            if iface and iface ~= "lo" then
                cached_net_iface = iface
                break
            end
        end
        f:close()
    end

    return cached_net_iface or ""
end

-- ===================================================================
-- Functions: Network Speed & Percentages (1 Gbit / 125 MB/s)
-- ===================================================================
function conky_get_downspeed()
    local iface = get_active_interface()
    local speed = conky_parse('${downspeed ' .. iface .. '}')
    return speed .. '/s'
end

function conky_get_upspeed()
    local iface = get_active_interface()
    local speed = conky_parse('${upspeed ' .. iface .. '}')
    return speed .. '/s'
end

function conky_down_percent(iface)
    if not iface or iface == "" then
        iface = get_active_interface()
    end
    local speed = tonumber(conky_parse('${downspeedf ' .. iface .. '}')) or 0
    local pct = (speed / 125000) * 100
    return math.min(pct, 100)
end

function conky_up_percent(iface)
    if not iface or iface == "" then
        iface = get_active_interface()
    end
    local speed = tonumber(conky_parse('${upspeedf ' .. iface .. '}')) or 0
    local pct = (speed / 125000) * 100
    return math.min(pct, 100)
end

-- ===================================================================
-- Function: Display Info (Resolution & Refresh Rate) - Cached
-- ===================================================================
function conky_get_display_info()
    -- If resolution was fetched previously, return cached value
    if cached_display_info then
        return cached_display_info
    end

    local cmd = [[kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) as $out | $out.modes[] | select(.id == $out.currentModeId) | "\(.size.width)x\(.size.height)@\( ((.refreshRate - (.refreshRate | round)) | if . < 0 then -. else . end) as $diff | if $diff < 0.01 then (.refreshRate | round) else ((.refreshRate * 100 | round) / 100) end)Hz"' 2>/dev/null | head -n1]]

    local h = io.popen(cmd)
    if not h then return "N/A" end
    
    local res = h:read("*l")
    h:close()

    if res and res ~= "" then
        cached_display_info = res
        return cached_display_info
    end

    return "N/A"
end

-- ===================================================================
-- Function: Get Scaling Factor (e.g. 100%, 125%, 150%) - Cached
-- ===================================================================
function conky_get_scale_factor()
    -- If scaling factor was calculated previously, return cached value
    if cached_scale_factor then
        return cached_scale_factor
    end

    -- 1. Read X11 Xft.dpi via xrdb (144 DPI = 150%, 120 DPI = 125%, 96 DPI = 100%)
    local cmd_dpi = [[xrdb -query 2>/dev/null | grep -i 'Xft.dpi' | grep -o '[0-9]*']]
    local h = io.popen(cmd_dpi)
    if h then
        local dpi = h:read("*l")
        h:close()
        if dpi and tonumber(dpi) and tonumber(dpi) > 0 then
            local calculated_scale = math.floor((tonumber(dpi) / 96) * 100 + 0.5)
            cached_scale_factor = string.format("%d%%", calculated_scale)
            return cached_scale_factor
        end
    end

    -- 2. Fallback: KScreen scale factor
    local cmd_kscreen = [[kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | "\((.scale * 100 | round))%"' 2>/dev/null | head -n1]]
    h = io.popen(cmd_kscreen)
    if h then
        local scale = h:read("*l")
        h:close()
        if scale and scale ~= "" and scale ~= "null%" then
            cached_scale_factor = scale
            return cached_scale_factor
        end
    end

    cached_scale_factor = "100%"
    return cached_scale_factor
end

-- ===================================================================
-- Resolution & Refresh Rate Watcher Starter
-- ===================================================================
function start_resolution_watcher()
    if watcher_started then return end
    watcher_started = true
    
    os.execute("nohup ~/.config/conky/display_watcher.sh >/dev/null 2>&1 &")
end

start_resolution_watcher()
