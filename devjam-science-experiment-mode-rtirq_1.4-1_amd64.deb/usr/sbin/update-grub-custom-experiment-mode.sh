#!/bin/bash
set -euo pipefail

# Predefine GRUB variables
GRUB_CMDLINE_LINUX_DEFAULT=""
GRUB_CMDLINE_LINUX_DEFAULT_EXPERIMENT_MODE=""

# Source main GRUB config
[[ -f /etc/default/grub ]] && . /etc/default/grub

# Source drop-in configs
if compgen -G "/etc/default/grub.d/*.cfg" > /dev/null; then
    for f in /etc/default/grub.d/*.cfg; do
        [[ -f "$f" ]] && . "$f"
    done
fi

# Combine kernel parameters
KERNEL_PARAMETERS="$(echo "$GRUB_CMDLINE_LINUX_DEFAULT $GRUB_CMDLINE_LINUX_DEFAULT_EXPERIMENT_MODE" | xargs)"

# Custom GRUB file
CUSTOM_FILE="/etc/grub.d/11_experiment_mode_liquorix"
ROOT_UUID=$(blkid -s UUID -o value "$(findmnt -n -o SOURCE /)")

# Find all kernels in /boot (generic + Liquorix)
mapfile -t ALL_KERNELS < <(printf "%s\n" /boot/vmlinuz-* 2>/dev/null)

if [[ ${#ALL_KERNELS[@]} -eq 0 ]]; then
    echo "No kernels found in /boot!" >&2
    exit 1
fi

# Separate Liquorix and generic kernels
LIQUORIX_KERNELS=()
GENERIC_KERNELS=()
for KERNEL in "${ALL_KERNELS[@]}"; do
    FILE=$(basename "$KERNEL")
    if [[ "$FILE" == *-liquorix* ]]; then
        LIQUORIX_KERNELS+=("$KERNEL")
    else
        GENERIC_KERNELS+=("$KERNEL")
    fi
done

# Sort newest to oldest
mapfile -t LIQUORIX_KERNELS < <(printf "%s\n" "${LIQUORIX_KERNELS[@]}" | sort -Vr)
mapfile -t GENERIC_KERNELS < <(printf "%s\n" "${GENERIC_KERNELS[@]}" | sort -Vr)

# Combine for submenu: Liquorix first
ALL_KERNELS_SORTED=("${LIQUORIX_KERNELS[@]}" "${GENERIC_KERNELS[@]}")

# Latest kernel for top-level menuentry: newest Liquorix if available, else newest overall
if [[ ${#LIQUORIX_KERNELS[@]} -gt 0 ]]; then
    LATEST_KERNEL="${LIQUORIX_KERNELS[0]}"
else
    LATEST_KERNEL="${ALL_KERNELS_SORTED[0]}"
fi
LATEST_KERNEL_FILE=$(basename "$LATEST_KERNEL")
LATEST_INITRD_FILE="initrd.img-${LATEST_KERNEL_FILE#vmlinuz-}"

# Generate custom GRUB entry
cat <<EOF | tee "$CUSTOM_FILE" >/dev/null
#!/bin/sh
echo 1>&2 "Adding Experiment Mode GRUB entries"
exec tail -n +4 \$0

# Top-level entry: latest Liquorix kernel if available
menuentry "Debian GNU/Linux - Experiment Mode" {
	savedefault
	load_video
	gfxmode \$linux_gfx_mode
	insmod gzio
	if [ x\$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
	insmod part_gpt
	insmod ext2
	search --no-floppy --fs-uuid --set=root $ROOT_UUID
	echo	'Loading Linux ${LATEST_KERNEL_FILE#vmlinuz-} ...'
	linux	/boot/$LATEST_KERNEL_FILE root=UUID=$ROOT_UUID ro $KERNEL_PARAMETERS
	echo	'Loading initial ramdisk ...'
	initrd	/boot/$LATEST_INITRD_FILE
}

# Submenu: advanced options for all kernels
submenu "Advanced options for Debian GNU/Linux - Experiment Mode" {
EOF

# Add all kernels to submenu with Debian-style naming
for KERNEL in "${ALL_KERNELS_SORTED[@]}"; do
    KERNEL_FILE=$(basename "$KERNEL")
    INITRD_FILE="initrd.img-${KERNEL_FILE#vmlinuz-}"
    KERNEL_VERSION="${KERNEL_FILE#vmlinuz-}"

    # Mark Liquorix kernels
    if [[ "$KERNEL_VERSION" == *-liquorix* ]]; then
        MARK=" (Liquorix)"
    else
        MARK=""
    fi

    cat <<EOF | tee -a "$CUSTOM_FILE" >/dev/null
	menuentry "Debian GNU/Linux, with Linux $KERNEL_VERSION$MARK - Experiment Mode" {
		savedefault
		load_video
		gfxmode \$linux_gfx_mode
		insmod gzio
		if [ x\$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
		insmod part_gpt
		insmod ext2
		search --no-floppy --fs-uuid --set=root $ROOT_UUID
		echo	'Loading Linux $KERNEL_VERSION ...'
		linux	/boot/$KERNEL_FILE root=UUID=$ROOT_UUID ro $KERNEL_PARAMETERS
		echo	'Loading initial ramdisk ...'
		initrd	/boot/$INITRD_FILE
	}
EOF
done

# Close submenu
echo "}" >> "$CUSTOM_FILE"

chmod +x "$CUSTOM_FILE"

echo "Experiment Mode GRUB entries updated. Latest kernel: $LATEST_KERNEL_FILE"
