#!/bin/sh

mkdir -p /etc/sddm.conf.d

cat > /etc/sddm.conf.d/autologin.conf << !
[Autologin]
User=user
Session=kodi.desktop
!

cat > /etc/sddm.conf << !
[Autologin]
User=user
Session=kodi.desktop
!

