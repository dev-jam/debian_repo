#!/bin/sh

mkdir -p /etc/sddm.conf.d

cat > /etc/sddm.conf.d/autologin.conf << !
[Autologin]
User=user
Session=plasmax11.desktop
!

cat > /etc/sddm.conf << !
[Autologin]
User=user
Session=plasmax11.desktop
!

mkdir -p /etc/X11/xorg.conf.d

cat > /etc/X11/xorg.conf.d/21-compositing.conf << !
Section "Extensions"
    Option "Composite" "Enable"
EndSection
!
