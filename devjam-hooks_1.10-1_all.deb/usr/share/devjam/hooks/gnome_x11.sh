#!/bin/sh

cat > /etc/sddm.conf << !
[Autologin]
User=user
Session=gnome-xorg.desktop
!

if [ -e /etc/lightdm/lightdm.conf ]
then
	sed -i -r -e "s|^#.*autologin-user=.*\$|autologin-user=user|" \
		  -e "s|^#.*autologin-user-timeout=.*\$|autologin-user-timeout=0|" \
		  -e "s|^#.*autologin-session=.*\$|autologin-session=gnome-xorg.desktop|" \
	/etc/lightdm/lightdm.conf
fi

mkdir -p /etc/X11/xorg.conf.d

cat > /etc/X11/xorg.conf.d/21-compositing.conf << !
Section "Extensions"
    Option "Composite" "Disable"
EndSection
!
