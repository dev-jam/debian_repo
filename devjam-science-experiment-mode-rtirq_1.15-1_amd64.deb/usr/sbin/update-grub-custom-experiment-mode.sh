#!/bin/bash
set -euo pipefail

# ----------------------------
# Function: check if in chroot
# ----------------------------
in_chroot() {
    # Marker file for chroot
    [ -f /.chroot ] && return 0

    # Compare root of PID 1 with current root
    if [ -d /proc/1/root ]; then
        [ "$(readlink /proc/1/root)" != "/" ] && return 0
    fi

    return 1
}

# ----------------------------
# Exit safely if in chroot
# ----------------------------
if in_chroot; then
    echo "Skipping GRUB custom update: detected chroot/bootstrap environment"
    exit 0
fi

# ----------------------------
# Predefine GRUB variables
# ----------------------------
GRUB_CMDLINE_LINUX_DEFAULT=""
GRUB_CMDLINE_LINUX_DEFAULT_EXPERIMENT_MODE=""

# Source main GRUB config
[[ -f /etc/default/grub ]] && . /etc/default/grub

# Source drop-in configs safely
for f in /etc/default/grub.d/*.cfg; do
    [[ -f "$f" ]] || continue
    . "$f"
done

# Combine kernel parameters
KERNEL_PARAMETERS="$(echo "$GRUB_CMDLINE_LINUX_DEFAULT $GRUB_CMDLINE_LINUX_DEFAULT_EXPERIMENT_MODE" | xargs)"

# ----------------------------
# Detect ROOT_UUID safely (non-interactive)
# ----------------------------
ROOT_DEV=$(findmnt -n -o SOURCE / || true)
ROOT_UUID=""
if [ -n "$ROOT_DEV" ]; then
    ROOT_UUID=$(blkid -s UUID -o value "$ROOT_DEV" || true)
fi

if [ -z "$ROOT_UUID" ]; then
    echo "Skipping GRUB custom update: could not detect root UUID"
    exit 0
fi

# ----------------------------
# Custom GRUB file
# ----------------------------
CUSTOM_FILE="/etc/grub.d/11_experiment_mode"

# Find all kernels in /boot (generic + Liquorix)
mapfile -t ALL_KERNELS < <(printf "%s\n" /boot/vmlinuz-*)

if [[ ${#ALL_KERNELS[@]} -eq 0 ]]; then
    echo "Skipping GRUB custom update: no kernels found in /boot"
    exit 0
fi

# Separate Liquorix and generic kernels
LIQUORIX_KERNELS=()
GENERIC_KERNELS=()
for KERNEL in "${ALL_KERNELS[@]}"; do
    FILE=$(basename "$KERNEL")
    if [[ "$FILE" == *-liquorix* ]]; then
        LIQUORIX_KERNELS+=("$KERNEL")
    else
        GENERIC_KERNELS+=("$KERNEL")
    fi
done

# Sort newest to oldest
mapfile -t LIQUORIX_KERNELS < <(printf "%s\n" "${LIQUORIX_KERNELS[@]}" | sort -Vr)
mapfile -t GENERIC_KERNELS < <(printf "%s\n" "${GENERIC_KERNELS[@]}" | sort -Vr)

# Combine for submenu: Liquorix first
ALL_KERNELS_SORTED=("${LIQUORIX_KERNELS[@]}" "${GENERIC_KERNELS[@]}")

# Latest kernel for top-level menuentry: newest Liquorix if available, else newest overall
LATEST_KERNEL="${LIQUORIX_KERNELS[0]:-${ALL_KERNELS_SORTED[0]}}"
LATEST_KERNEL_FILE=$(basename "$LATEST_KERNEL")
LATEST_INITRD_FILE="initrd.img-${LATEST_KERNEL_FILE#vmlinuz-}"

# ----------------------------
# Generate custom GRUB entry
# ----------------------------
cat > "$CUSTOM_FILE" <<EOF
#!/bin/sh
echo 1>&2 "Adding Experiment Mode GRUB entries"
exec tail -n +4 \$0

# Top-level entry: latest Liquorix kernel if available
menuentry "Debian GNU/Linux - Experiment Mode" {
	savedefault
	load_video
	gfxmode \$linux_gfx_mode
	insmod gzio
	if [ x\$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
	insmod part_gpt
	insmod ext2
	search --no-floppy --fs-uuid --set=root $ROOT_UUID
	echo	'Loading Linux ${LATEST_KERNEL_FILE#vmlinuz-} ...'
	linux	/boot/$LATEST_KERNEL_FILE root=UUID=$ROOT_UUID ro $KERNEL_PARAMETERS
	echo	'Loading initial ramdisk ...'
	initrd	/boot/$LATEST_INITRD_FILE
}

# Submenu: advanced options for all kernels
submenu "Advanced options for Debian GNU/Linux - Experiment Mode" {
EOF

# Add all kernels to submenu
for KERNEL in "${ALL_KERNELS_SORTED[@]}"; do
    KERNEL_FILE=$(basename "$KERNEL")
    INITRD_FILE="initrd.img-${KERNEL_FILE#vmlinuz-}"
    KERNEL_VERSION="${KERNEL_FILE#vmlinuz-}"

    MARK=""
    [[ "$KERNEL_VERSION" == *-liquorix* ]] && MARK=" (Liquorix)"

    cat >> "$CUSTOM_FILE" <<EOF
	menuentry "Debian GNU/Linux, with Linux $KERNEL_VERSION$MARK - Experiment Mode" {
		savedefault
		load_video
		gfxmode \$linux_gfx_mode
		insmod gzio
		if [ x\$grub_platform = xxen ]; then insmod xzio; insmod lzopio; fi
		insmod part_gpt
		insmod ext2
		search --no-floppy --fs-uuid --set=root $ROOT_UUID
		echo	'Loading Linux $KERNEL_VERSION ...'
		linux	/boot/$KERNEL_FILE root=UUID=$ROOT_UUID ro $KERNEL_PARAMETERS
		echo	'Loading initial ramdisk ...'
		initrd	/boot/$INITRD_FILE
	}
EOF
done

echo "}" >> "$CUSTOM_FILE"

chmod +x "$CUSTOM_FILE"

echo "Experiment Mode GRUB entries updated. Latest kernel: $LATEST_KERNEL_FILE"
