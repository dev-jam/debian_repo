#!/bin/bash
# Detects changes in screen resolution, refresh rate, and scaling factor
# (supports both X11 and Wayland) and restarts only the Conky process.

pidfile="/tmp/conky_display_watcher.pid"

if [ -f "$pidfile" ] && kill -0 "$(cat "$pidfile")" 2>/dev/null; then
    exit 0
fi
echo $$ > "$pidfile"
trap 'rm -f "$pidfile"' EXIT

CONKY_CONF="$HOME/.config/conky/conky.conf"

# SAFELY finds only the PIDs of actual conky binary processes (prevents killing
# terminals, text editors, or scripts that contain 'conky' in their path/name).
find_conky_pids() {
    # Use pidof to grab genuine binary executables only
    local pids
    pids=$(pidof conky 2>/dev/null)
    
    # Fallback if pids is empty (e.g. specific AppImage executables)
    if [ -z "$pids" ]; then
        for p in /proc/[0-9]*; do
            pid="${p##*/}"
            [ "$pid" = "$$" ] && continue
            exe=$(readlink -f "$p/exe" 2>/dev/null)
            if [[ "$exe" == */conky ]]; then
                pids="$pids $pid"
            fi
        done
    fi

    echo "$pids"
}

get_running_conky_cmd() {
    for pid in $(find_conky_pids); do
        tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null
        return
    done
}

get_mode() {
    # Get display mode (resolution + Hz) via KScreen / jq (with xrandr fallback)
    local mode
    mode=$(timeout 1s kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) as $out | $out.modes[] | select(.id == $out.currentModeId) | "\(.size.width)x\(.size.height)_\(.refreshRate)"' 2>/dev/null | head -n1)
    
    if [ -z "$mode" ] || [ "$mode" = "null" ]; then
        mode=$(xrandr --current 2>/dev/null | awk '/\*/ {for(i=1;i<=NF;i++) if($i ~ /\*/) print $1 "_" $i}' | head -n1)
    fi

    # Get scale factor: X11 via Xft.dpi, otherwise KScreen
    local dpi
    dpi=$(xrdb -query 2>/dev/null | grep -i 'Xft.dpi' | grep -o '[0-9]*')

    if [ -z "$dpi" ]; then
        dpi=$(timeout 1s kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | (.scale * 100 | round)' 2>/dev/null | head -n1)
        [ -z "$dpi" ] && dpi=96
    fi

    echo "${mode}_scale${dpi}"
}

LAST_MODE=$(get_mode)

while true; do
    sleep 2
    NEW_MODE=$(get_mode)

    if [ -n "$NEW_MODE" ] && [ "$NEW_MODE" != "$LAST_MODE" ]; then
        running_cmd=$(get_running_conky_cmd)

        # Specifically kill ONLY Conky processes
        for pid in $(find_conky_pids); do
            kill "$pid" 2>/dev/null
        done
        sleep 1

        if [ -n "$running_cmd" ]; then
            nohup $running_cmd >/dev/null 2>&1 &
        else
            nohup conky -c "$CONKY_CONF" >/dev/null 2>&1 &
        fi

        LAST_MODE="$NEW_MODE"
    fi
done
