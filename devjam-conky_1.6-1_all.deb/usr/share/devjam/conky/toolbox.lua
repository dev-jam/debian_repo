-- ===================================================================
-- Global Variables for CPU Power Measurement
-- ===================================================================
local last_energy = nil
local last_time = nil

-- ===================================================================
-- Global Variables & State for Resolution Watcher & Caching
-- ===================================================================
local watcher_started = false
local cached_display_info = nil
local cached_scale_factor = nil

-- ===================================================================
-- Function: Calculate Display Scale Factor (Exacter matchen op xrdb)
-- ===================================================================
function get_scale(size_factor)
    size_factor = size_factor or 0.8
    local base_scale = 1.0

    -- 1. Eerst Xft.dpi via xrdb
    local handle = io.popen("xrdb -query 2>/dev/null | grep -i 'Xft.dpi'")
    if handle then
        local output = handle:read("*a")
        handle:close()
        if output then
            -- Zoekt puur naar het getal aan het einde van de Xft.dpi regel
            local dpi_str = output:match("(%d+)%s*$")
            local dpi = tonumber(dpi_str)
            if dpi and dpi > 0 then
                base_scale = dpi / 96.0
            end
        end
    end

    -- 2. Fallback: Alleen als base_scale exact 1.0 is, vraag KScreen via jq
    if base_scale == 1.0 then
        local kwin_handle = io.popen("kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | .scale' 2>/dev/null | head -n1")
        if kwin_handle then
            local kwin_scale_str = kwin_handle:read("*a")
            kwin_handle:close()
            local kwin_scale = tonumber(kwin_scale_str)
            if kwin_scale and kwin_scale > 0 then
                base_scale = kwin_scale
            end
        end
    end

    return base_scale * size_factor
end

-- ===================================================================
-- Function: Get CPU Model / Brand Name
-- ===================================================================
function conky_get_cpu_name()
    local f = io.open("/proc/cpuinfo", "r")
    if not f then return "N/A" end

    local model_name = nil
    for line in f:lines() do
        model_name = line:match("^model name%s*:%s*(.+)")
        if model_name then break end
    end
    f:close()

    if model_name then
        -- Schoon de naam op voor een strakke Conky layout (haalt overbodige merktekens weg)
        model_name = model_name:gsub("%(R%)", "")
                              :gsub("%(TM%)", "")
                              :gsub("12th Gen ", "")
                              :gsub("13th Gen ", "")
                              :gsub("14th Gen ", "")
                              :gsub("Processor", "")
                              :gsub("CPU", "")
                              :gsub("%s+", " ")
                              :match("^%s*(.-)%s*$")
        return model_name
    end

    return "N/A"
end

-- ===================================================================
-- Function: CPU Scaling Driver (e.g. intel_pstate, amd-pstate)
-- ===================================================================
function conky_get_cpu_driver()
    local f = io.open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_driver", "r")
    if not f then return "N/A" end
    
    local driver = f:read("*l")
    f:close()
    
    if driver and driver ~= "" then
        return driver
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: Universal CPU Temperature (sensors + jq)
-- ===================================================================
function conky_get_cpu_temp()
    local cmd = [[sensors -j 2>/dev/null | jq -r 'to_entries[] | select(.key | test("^(coretemp|k10temp|zenpower|cpu_thermal)")) | .value | to_entries[] | select(.key | test("^(CPU Package|Package|Tctl|Tdie)")) | .. | .temp1_input? // .temp2_input? // empty' 2>/dev/null | head -n1]]
    
    local handle = io.popen(cmd)
    if not handle then return "N/A" end
    
    local temp_str = handle:read("*l")
    handle:close()
    
    local temp = tonumber(temp_str)
    if temp then
        return string.format("%d°C", math.floor(temp + 0.5))
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: CPU Max Frequency Across All Cores
-- ===================================================================
function conky_get_cpu_freq_max()
    local max_khz = 0
    
    -- Zoek in alle cpufreq/scaling_cur_freq bestanden
    local p = io.popen("ls /sys/devices/system/cpu/cpu*/cpufreq/scaling_cur_freq 2>/dev/null")
    if p then
        for file_path in p:lines() do
            local f = io.open(file_path, "r")
            if f then
                local val = tonumber(f:read("*l"))
                f:close()
                if val and val > max_khz then
                    max_khz = val
                end
            end
        end
        p:close()
    end

    if max_khz > 0 then
        local ghz = max_khz / 1000000
        return string.format("%.2f GHz", ghz)
    end

    return "N/A"
end

-- ===================================================================
-- Function: CPU Scaling Governor
-- ===================================================================
function conky_get_cpu_governor()
    local f = io.open("/sys/devices/system/cpu/cpu0/cpufreq/scaling_governor", "r")
    if not f then return "N/A" end
    
    local gov = f:read("*l")
    f:close()
    
    if gov and gov ~= "" then
        return gov
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: CPU Energy Performance Preference (EPP)
-- ===================================================================
function conky_get_cpu_epp()
    local f = io.open("/sys/devices/system/cpu/cpu0/cpufreq/energy_performance_preference", "r")
    if not f then return "N/A" end
    
    local epp = f:read("*l")
    f:close()
    
    if epp and epp ~= "" then
        return epp
    end
    
    return "N/A"
end

-- ===================================================================
-- Function: CPU Power Draw (intel-rapl)
-- ===================================================================
function conky_get_cpu_power()
    local file = io.open("/sys/class/powercap/intel-rapl/intel-rapl:0/energy_uj", "r")
    if not file then return "N/A" end
    
    local energy_str = file:read("*all")
    file:close()
    
    local energy = tonumber(energy_str)
    
    -- Lees exacte systeem-uptime in seconden met microseconden-precisie
    local now = nil
    local uptime_file = io.open("/proc/uptime", "r")
    if uptime_file then
        local uptime_str = uptime_file:read("*all")
        uptime_file:close()
        now = tonumber(uptime_str:match("^(%S+)"))
    else
        now = os.time()
    end
    
    if last_energy and last_time and energy and now then
        local de = energy - last_energy
        local dt = now - last_time
        
        if dt > 0 and de >= 0 then
            local watts = (de / dt) / 1000000
            last_energy = energy
            last_time = now
            return string.format("%.2f W", watts)
        end
    end
    
    last_energy = energy
    last_time = now
    return "N/A"
end

-- ===================================================================
-- Functions: Network Percentage (1 Gbit / 125 MB/s)
-- ===================================================================
function conky_down_percent(iface)
    local speed = tonumber(conky_parse('${downspeedf ' .. (iface or '') .. '}')) or 0
    local pct = (speed / 125000) * 100
    return math.min(pct, 100)
end

function conky_up_percent(iface)
    local speed = tonumber(conky_parse('${upspeedf ' .. (iface or '') .. '}')) or 0
    local pct = (speed / 125000) * 100
    return math.min(pct, 100)
end

-- ===================================================================
-- Function: Display Info (Resolution & Refresh Rate) - Met Caching!
-- ===================================================================
function conky_get_display_info()
    -- Als de resolutie al eerder is opgehaald, gebruik direct de cache
    if cached_display_info then
        return cached_display_info
    end

    local cmd = [[kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) as $out | $out.modes[] | select(.id == $out.currentModeId) | "\(.size.width)x\(.size.height)@\( ((.refreshRate - (.refreshRate | round)) | if . < 0 then -. else . end) as $diff | if $diff < 0.01 then (.refreshRate | round) else ((.refreshRate * 100 | round) / 100) end)Hz"' 2>/dev/null | head -n1]]

    local h = io.popen(cmd)
    if not h then return "N/A" end
    
    local res = h:read("*l")
    h:close()

    if res and res ~= "" then
        cached_display_info = res
        return cached_display_info
    end

    return "N/A"
end

-- ===================================================================
-- Function: Get Scaling Factor (e.g. 100%, 125%, 150%) - Met Caching!
-- ===================================================================
function conky_get_scale_factor()
    -- Als de schaal al eerder is berekend, gebruik direct de cache
    if cached_scale_factor then
        return cached_scale_factor
    end

    -- 1. Lees X11 Xft.dpi uit via xrdb (144 DPI = 150%, 120 DPI = 125%, 96 DPI = 100%)
    local cmd_dpi = [[xrdb -query 2>/dev/null | grep -i 'Xft.dpi' | grep -o '[0-9]*']]
    local h = io.popen(cmd_dpi)
    if h then
        local dpi = h:read("*l")
        h:close()
        if dpi and tonumber(dpi) and tonumber(dpi) > 0 then
            local calculated_scale = math.floor((tonumber(dpi) / 96) * 100 + 0.5)
            cached_scale_factor = string.format("%d%%", calculated_scale)
            return cached_scale_factor
        end
    end

    -- 2. Fallback: KScreen schaalfactor
    local cmd_kscreen = [[kscreen-doctor -j 2>/dev/null | jq -r '.outputs[] | select(.enabled == true) | select(.scale != null) | "\((.scale * 100 | round))%"' 2>/dev/null | head -n1]]
    h = io.popen(cmd_kscreen)
    if h then
        local scale = h:read("*l")
        h:close()
        if scale and scale ~= "" and scale ~= "null%" then
            cached_scale_factor = scale
            return cached_scale_factor
        end
    end

    cached_scale_factor = "100%"
    return cached_scale_factor
end

-- ===================================================================
-- Resolution & Refresh Rate Watcher Starter
-- ===================================================================
function start_resolution_watcher()
    if watcher_started then return end
    watcher_started = true
    
    os.execute("nohup ~/.config/conky/display_watcher.sh >/dev/null 2>&1 &")
end

start_resolution_watcher()
