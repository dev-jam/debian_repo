#!/bin/sh

rm -rf eigen-eigen-bdd17ee3b1b3
tar xjf 3.2.5.tar.bz2
