export KWIN_PERSISTENT_VBO=1          # default?
export KWIN_USE_BUFFER_AGE=1          # default
export KWIN_EXPLICIT_SYNC=0           # Xorg takes care of it
export KWIN_X11_NO_SYNC_TO_VBLANK=1   # Xorg takes care of it
export KWIN_USE_INTEL_SWAP_EVENT=1    # not default, should be relevant only on glx, but we are going to use EGL
