#ifndef ___version_generated_h___
#define ___version_generated_h___

#define VBOX_VERSION_MAJOR 6
#define VBOX_VERSION_MINOR 1
#define VBOX_VERSION_BUILD 32
#define VBOX_VERSION_STRING_RAW "6.1.32"
#define VBOX_VERSION_STRING "6.1.32_Debian"
#define VBOX_API_VERSION_STRING "6_1"

#define VBOX_PRIVATE_BUILD_DESC "Private build by root"

#endif
